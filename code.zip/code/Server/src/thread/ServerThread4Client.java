package thread;

import info.Local_Room_info;
import info.Lock_info;
import info.Remote_Room_info;
import info.Server_info;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import server.Server;
import server.ServerMessages;


public class ServerThread4Client extends Thread {

	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();
	private String identity = null;
	private String currentRoom = "";
	private String serverID = Server.server_id;

	public ServerThread4Client(Socket socket) throws IOException {
		
		this.socket = socket;
		this.out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
		//this.out = new PrintWriter(socket.getOutputStream());
		this.in = new BufferedReader(new InputStreamReader(
				socket.getInputStream(), "UTF-8"));
		System.out.println("this server:" + Server.server_id);
		System.out.println(socket);
	}

	@SuppressWarnings("unchecked")
	public void run() {
		int index = 0;
		boolean flag = true;
		JSONObject message;
		try {
			while(flag){
				System.out.println("waiting for message...");
				JSONObject send2Server, send2Client, send2RoomMate = new JSONObject();
				message = (JSONObject) parser.parse(in.readLine());
				System.out.println(message);
				switch (message.get("type").toString()) {
				case "newidentity":
					identity = message.get("identity").toString();
					index = Integer.parseInt(message.get("index").toString());
					boolean approved = checkIdentityValid(identity);
					if(approved){
						send2Server = ServerMessages.lockIdentityRequest(serverID, message.get("identity").toString());
						broadcast2Servers(send2Server);
						while(true){
							sleep(10);
							if (Server.isIsreply2Client_identity()) {
								if (Server.isIdentitypass()) {
									send2Client = ServerMessages.lockIdentityReply2Client(Server.isIdentitypass());
									reply2Client(send2Client);
									add2NewRoom(identity, Server.mainhall_id, index);
									currentRoom = Server.mainhall_id;
									send2RoomMate = ServerMessages.roomChangeMessage(identity, "", Server.mainhall_id);
									broadcast2Clients(send2RoomMate, currentRoom);
									Server.setIdentitypass(false);
								}else{
									send2Client = ServerMessages.lockIdentityReply2Client(Server.isIdentitypass());
									reply2Client(send2Client);
									flag = false;
								}
								Server.setIsreply2Client_identity(false);
								break;
							}
						}
					}else{
						send2Client = ServerMessages.lockIdentityReply2Client(approved);
						reply2Client(send2Client);
						flag = false;
					}
					break;
				case "list":
					JSONArray rooms = new JSONArray();
					rooms.addAll(getLocalRooms());
					rooms.addAll(getRemoteRooms());
					send2Client = ServerMessages.getListReply(rooms);
					reply2Client(send2Client);
					break;
				case "who":
					ArrayList<String> roomcontent = new ArrayList<String>();
					HashMap<String,Integer> hashMap = new HashMap<>(); 
					ArrayList<Integer> index1 = new ArrayList<>();
					String owner = null;
					for (Local_Room_info local_Room_info : Server.local_room_infos) {
						if (local_Room_info.getRoom_id().equals(currentRoom)) {
							roomcontent = local_Room_info.getRoom_content();
							owner = local_Room_info.getOwner();
							hashMap = local_Room_info.getIdentityWithIndex();
						}
					}
					for(String identity : roomcontent){
						index1.add(hashMap.get(identity));
					}
					JSONArray contents = new JSONArray();
					contents.addAll(roomcontent);
					JSONArray indexs = new JSONArray();
					indexs.addAll(index1);
					send2Client = ServerMessages.getWhoReply(currentRoom, contents, owner, indexs);
					reply2Client(send2Client);
					break;
				case "createroom":
					String newroomid = message.get("roomid").toString();
					boolean approved1 = checkRoomValid(newroomid);
					if(approved1){
						send2Server = ServerMessages.lockRoomRequest(serverID, newroomid);
						broadcast2Servers(send2Server);
						while(true){
							sleep(10);
							if (Server.isIsreply2Client_room()) {
								if (Server.isRoompass()) {
									send2Client = ServerMessages.lockRoomReply2Client(newroomid, Server.roompass);
									reply2Client(send2Client);
									send2RoomMate = ServerMessages.roomChangeMessage(identity, currentRoom, newroomid);
									broadcast2Clients(send2RoomMate, currentRoom);
									Server.local_room_infos.add(new Local_Room_info(newroomid, identity, new ArrayList<String>(), new HashMap<String,Integer>()));
									move2NewRoom(identity, currentRoom,	newroomid, index);
									currentRoom = newroomid;
									Server.setIdentitypass(false);
								}else{
									send2Client = ServerMessages.lockRoomReply2Client(newroomid, Server.isIdentitypass());
									reply2Client(send2Client);
								}
								Server.setIsreply2Client_identity(false);
								break;
							}
						}
					}else{
						send2Client = ServerMessages.lockRoomReply2Client(newroomid, approved1);
						reply2Client(send2Client);
					}
					break;
				case "join":
					String roomid = message.get("roomid").toString();
					boolean boolean1 = checkInRoom(roomid,"global") && !isRoomOwner(identity);
					if(boolean1){
						if(checkInRoom(roomid,"local")){
							System.out.println("room in local");
							move2NewRoom(identity, currentRoom, roomid, index);
							send2RoomMate = ServerMessages.roomChangeMessage(identity, currentRoom, roomid);
							broadcast2Clients(send2RoomMate, currentRoom);
							broadcast2Clients(send2RoomMate, roomid);
							currentRoom = roomid;
						}else{
							System.out.println("room in remote");
							Server_info server_info = getRemoteRoomServerInfo(roomid);
							send2Client = ServerMessages.routeMessageReply(roomid, server_info.getServer_address(), server_info.getClients_port());
							reply2Client(send2Client);
							leaveRoom(identity, currentRoom);
						}
					}else{
						send2RoomMate = ServerMessages.roomChangeMessage(identity, currentRoom, currentRoom);
						reply2Client(send2RoomMate);
					}
					break;
				case "movejoin":
					identity = message.get("identity").toString();
					String formerRoom = message.get("former").toString();
					String destinationRoom = message.get("roomid").toString();
					currentRoom = destinationRoom;
					if(checkInRoom(destinationRoom, "local")){
						add2NewRoom(identity, destinationRoom, index);
						currentRoom = destinationRoom;
						send2Client = ServerMessages.moveJoinReply(true, serverID);
						reply2Client(send2Client);
						send2RoomMate = ServerMessages.roomChangeMessage(identity, formerRoom, destinationRoom);
						broadcast2Clients(send2RoomMate, destinationRoom);
					}else{
						add2NewRoom(identity, Server.mainhall_id, index);
						currentRoom = Server.mainhall_id;
					}
					break;
				case "deleteroom":
					roomid = message.get("roomid").toString();
					if(getRoomOwner(roomid).equals(identity)){
						send2Server = ServerMessages.deleteRoomInformation(serverID, roomid);
						broadcast2Servers(send2Server);
						ArrayList<String> deletedRoomMembers = new ArrayList<String>();
						deletedRoomMembers = getRoomMembers(currentRoom);		
						for (String identity : deletedRoomMembers) {
							send2RoomMate = ServerMessages.roomChangeMessage(identity, currentRoom, Server.mainhall_id);
							broadcast2Clients(send2RoomMate, currentRoom);
							broadcast2Clients(send2RoomMate, Server.mainhall_id);	
						}
						
						HashMap<String,Integer> deletedHashMap = getRoom(currentRoom).getIdentityWithIndex();
						
						for (String identity : deletedRoomMembers) {
							add2NewRoom(identity, Server.mainhall_id, deletedHashMap.get(identity));
						}
						setDeletedIdentityCurrentRoom(deletedRoomMembers);
						send2Client = ServerMessages.deleteRoomReply(roomid, true);
						reply2Client(send2Client);
						deleteLocalRoom(roomid);
					}else{
						send2Client = ServerMessages.deleteRoomReply(roomid, false);
						reply2Client(send2Client);
					}
					Server.terminateServerConnection();
					break;
				case "message":
					send2RoomMate = ServerMessages.getMessage(message.get("content").toString(), identity);
					broadcast2Clients(send2RoomMate, currentRoom);
					break;
				case "quit":
					if(getRoomOwner(currentRoom).equals(identity)){
					
						System.out.println("is owner");
						send2Server = ServerMessages.deleteRoomInformation(serverID, currentRoom);
						broadcast2Servers(send2Server);
						
						ArrayList<String> deletedRoomMembers = new ArrayList<String>();
						deletedRoomMembers = getRoomMembers(currentRoom);
						for (String identity : deletedRoomMembers) {
							send2RoomMate = ServerMessages.roomChangeMessage(identity, currentRoom, Server.mainhall_id);
							broadcast2Clients(send2RoomMate, currentRoom);
							broadcast2Clients(send2RoomMate, Server.mainhall_id);
						}
						
						HashMap<String,Integer> deletedHashMap = getRoom(currentRoom).getIdentityWithIndex();
						
						for (String identity : deletedRoomMembers) {
							add2NewRoom(identity, Server.mainhall_id, deletedHashMap.get(identity));
						}
						
						send2Client = ServerMessages.deleteRoomReply(currentRoom, true);
						reply2Client(send2Client);
						deleteLocalRoom(currentRoom);
						setDeletedIdentityCurrentRoom(deletedRoomMembers);

						leaveRoom(identity, currentRoom);
						send2Client = ServerMessages.roomChangeMessage(identity, currentRoom, "");
						reply2Client(send2Client);
						flag = false;
					}else{
						leaveRoom(identity, currentRoom);
						send2Client = ServerMessages.roomChangeMessage(identity, currentRoom, "");
						reply2Client(send2Client);
						flag = false;
					}
					break;
				case "login":
					send2CentralServer(message);
					BufferedReader in = new BufferedReader(new InputStreamReader(
							Server.socket4CentralServer.getInputStream(), "UTF-8"));
					JSONObject message1 = (JSONObject) parser.parse(in.readLine());
					boolean loginApproved = Boolean.parseBoolean((String) message1.get("approved"));
					send2Client = ServerMessages.loginReply(loginApproved);
					reply2Client(send2Client);
					break;
				default:
					break;
				}
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			System.out.println("Communication Error: " + e.getMessage());
		} 
		finally{
			try {
				out.close();
				in.close();
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
	
	public String getCurrentRoom() {
		return currentRoom;
	}

	public void setCurrentRoom(String currentRoom) {
		this.currentRoom = currentRoom;
	}

	private void setDeletedIdentityCurrentRoom(ArrayList<String> deletedRoomMembers) {
		for(ServerThread4Client serverThread4Client : Server.client_thread_list){
			for(String identity : deletedRoomMembers){
				if(identity.equals(serverThread4Client.getIdentity())){
					serverThread4Client.setCurrentRoom(Server.mainhall_id);
				}
			}
		}
	}

	private void deleteLocalRoom(String roomid) {
		for (int i = Server.local_room_infos.size(); i > 0; i--) {
			if (Server.local_room_infos.get(i - 1).getRoom_id().equals(roomid))
				Server.local_room_infos.remove(Server.local_room_infos.get(i - 1));
		}
		
	}

	private void leaveRoom(String identity, String originRoom) {
		for (Local_Room_info local_room_infos : Server.local_room_infos) {
			if (local_room_infos.getRoom_id().equals(originRoom)) {
				local_room_infos.getRoom_content().remove(identity);
				local_room_infos.getIdentityWithIndex().remove(identity);
			}
		}
		
	}

	public Server_info getRemoteRoomServerInfo(String roomid) {
		for (Remote_Room_info remoteRoom_info : Server.remote_room_infos)
			if (remoteRoom_info.getRoomID().contains(roomid)) {
				String serverid = remoteRoom_info.getServerID();
				for(Server_info server_info : Server.remote_servers_infos)
					if(server_info.getServer_id().equals(serverid))
						return server_info;
			}
		return null;
	}

	public ArrayList<String> getLocalRooms() {
		ArrayList<String> local_roomsArrayList = new ArrayList<String>();
		for (Local_Room_info local_Room_info : Server.local_room_infos) {
			local_roomsArrayList.add(local_Room_info.getRoom_id());
		}
		return local_roomsArrayList;
	}

	private ArrayList<String> getRemoteRooms() {
		ArrayList<String> remote_roomsArrayList = new ArrayList<String>();
		for (Remote_Room_info remote_Room_info : Server.remote_room_infos) {
			remote_roomsArrayList.addAll(remote_Room_info.getRoomID());
		}
		return remote_roomsArrayList;
	}



	public boolean isAlphanumeric(String input) {
		String parttern = "^[A-Za-z][A-Za-z0-9]{2,15}$";
		Pattern p = Pattern.compile(parttern);
		Matcher m = p.matcher(input);
		return m.find();
	}
	
	public boolean checkDuplicateIdentity(String identity) {
		for (Local_Room_info local_room_info : Server.local_room_infos) {
			if (local_room_info.getRoom_content().contains(identity)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean checkLockedIdentity(String identity) {
		for (Lock_info lock_info : Server.lockedIdentityList) {
			if (identity.equals(lock_info.getIdentity()))
				return false;
		}
		return true;
	}
	
	public boolean checkDuplicateRoom(String roomID) {
		for (Local_Room_info local_room_info : Server.local_room_infos) {
			if (local_room_info.getRoom_content().contains(roomID)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean checkLockedRoom(String roomID) {
		for (Lock_info lock_info : Server.lockedIdentityList) {
			if (roomID.equals(lock_info.getIdentity()))
				return false;
		}
		return true;
	}
	
	public boolean checkIdentityValid(String identity){
		return (isAlphanumeric(identity) && checkDuplicateIdentity(identity) && checkLockedIdentity(identity));
	}
	
	public boolean checkRoomValid(String roomID){
		return (isAlphanumeric(roomID) && checkDuplicateRoom(roomID) && checkLockedRoom(roomID) && !isRoomOwner(identity));
	}
	
	public ArrayList<String> getRoomMembers(String roomid) {
		ArrayList<String> members = new ArrayList<String>();
		for (Local_Room_info local_Room_info : Server.local_room_infos) {
			if (local_Room_info.getRoom_id().equals(roomid)) {
				members = local_Room_info.getRoom_content();
			}
		}
		return members;
	}
	
	public void broadcast2Clients(JSONObject jsonObject, String roomid)
			throws IOException {
		String message = jsonObject.toJSONString();
		for(ServerThread4Client thread : Server.client_thread_list){
			ArrayList<String> members = new ArrayList<String>();
			members = getRoomMembers(roomid);
/*			if ((thread.getIdentity() != identity) && members.contains(thread.getIdentity())) {
				thread.getOut().println(message);
				thread.getOut().flush();
			}*/
			if (members.contains(thread.getIdentity())) {
				thread.getOut().println(message);
				thread.getOut().flush();
			}
		}
	}

	public void broadcast2Servers(JSONObject jsonObject) throws IOException
			{
		String message = jsonObject.toJSONString();
		if (!Server.init_server)
			Server.initialServerConnection();
		for(Socket socket : Server.socket4Server){
			//PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
			PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
			printWriter.println(message);
			printWriter.flush();
		}
	}
	
	public void reply2Client(JSONObject jsonObject) throws UnsupportedEncodingException{
		String message = jsonObject.toJSONString();
		out.println(message);
		out.flush();
	}
	
	public void add2NewRoom(String identity, String destinationRoom, Integer index) {
		for (Local_Room_info local_Room_info : Server.local_room_infos) {
			if (local_Room_info.getRoom_id().equals(destinationRoom)) {
				local_Room_info.getRoom_content().add(identity);
				local_Room_info.getIdentityWithIndex().put(identity, index);
			}
		}
	}
	
	public void move2NewRoom(String identity, String originRoom,
			String destinationRoom, Integer index) {
		for (Local_Room_info local_room_info : Server.local_room_infos) {
			if (local_room_info.getRoom_id().equals(originRoom)) {
				local_room_info.getRoom_content().remove(identity);
				local_room_info.getIdentityWithIndex().remove(identity);
			}
			if (local_room_info.getRoom_id().equals(destinationRoom)) {
				local_room_info.getRoom_content().add(identity);
				local_room_info.getIdentityWithIndex().put(identity, index);
			}
		}
	}
	
	public boolean checkInRoom(String roomid, String type) {
		ArrayList<String> totalRooms = new ArrayList<String>();
		if(type.equals("local")){
			totalRooms.addAll(getLocalRooms());
		}else if(type.equals("remote")){
			totalRooms.addAll(getRemoteRooms());
		}else{
			totalRooms.addAll(getLocalRooms());
			totalRooms.addAll(getRemoteRooms());
		}
		for (int i = 0; i < totalRooms.size(); i++) {
			if (totalRooms.get(i).equals(roomid)) {
				return true;
			}
		}
		return false;
	}
	
	public Local_Room_info getRoom(String roomid){
		for(Local_Room_info local_Room_info : Server.local_room_infos){
			if(local_Room_info.getRoom_id().equals(roomid))
				return local_Room_info;
		}
		return null;
	}
	
	public boolean isRoomOwner(String identity){
		for (Local_Room_info local_Room_info : Server.local_room_infos) {
			if (local_Room_info.getOwner().equals(identity)) {
				return true;
			}
		}
		return false;
	}
	
	public String getRoomOwner(String roomID){
		for (Local_Room_info local_Room_info : Server.local_room_infos) {
			if (local_Room_info.getRoom_id().equals(roomID)) {
				return local_Room_info.getOwner();
			}
		}
		return null;
	}
	
	public PrintWriter getOut() {
		return out;
	}

	public void setOut(PrintWriter out) {
		this.out = out;
	}
	
	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getCurrent() {
		return currentRoom;
	}

	public void setCurrent(String currentRoom) {
		this.currentRoom = currentRoom;
	}
	
	public void send2CentralServer(JSONObject jsonObject) throws IOException{
		String message = jsonObject.toJSONString();
		if (!Server.init_central_server)
			Server.initialCentralServerConnection();
		//PrintWriter printWriter = new PrintWriter(Server.socket4CentralServer.getOutputStream());
		PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(Server.socket4CentralServer.getOutputStream(), StandardCharsets.UTF_8), true);
		printWriter.println(message);
		printWriter.flush();
	}
}
