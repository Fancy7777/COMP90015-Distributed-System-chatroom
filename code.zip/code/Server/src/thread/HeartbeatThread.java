package thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;

import org.json.simple.JSONObject;

import info.Remote_Room_info;
import info.Server_info;
import server.Server;
import server.ServerMessages;

public class HeartbeatThread extends Thread {
	// failure handling
	public static HashMap<String, String> serverStatus = new HashMap<String, String>();
	public static String ServerOn = "on";
	public static String ServerOff = "off";
	
	@Override
	public void run() {
		try {
			sleep(10000);
		} catch (InterruptedException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		JSONObject send2Server = new JSONObject();
		
		while (true) {
			//construct a HashMap<String1, String2> for all other servers
			//initial data structure to be all off for all servers
			for(Server_info server_info : Server.remote_servers_infos){
				serverStatus.put(server_info.getServer_id(), ServerOff);
			}
			
			try {
				sleep(10000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			//broadcast to all other servers a heartbeatSignal message
			send2Server = ServerMessages.heartbeatSignal();
			
			
			try {
				ServerThread4Server.broadcast2Servers(send2Server);
			} catch (IOException |ConcurrentModificationException e1) {
				e1.printStackTrace();
			}
			
			//System.out.println("starting to terminateServerConnection");
			try {
				Server.terminateServerConnection();
			} catch (IOException |ConcurrentModificationException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			try {
				sleep(3000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			//loop through serverStatus, if value = "off", it means the server is down.
			//then remove the DEAD server from the serverlist in ServerState
			System.out.println("checking server status");
			for(String serverid : serverStatus.keySet()) {
				if (serverStatus.get(serverid).equals(ServerOff)) {
					System.out.println(serverid + " is down");

					try {
						for (Server_info serverInfo : Server.remote_servers_infos) {
							if (serverInfo.getServer_id().equals(serverid)) {
								
								try {
									newConfig(serverInfo.getServer_id());
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
								Server.remote_servers_infos.remove(serverInfo);
								ArrayList roomToRemove = new ArrayList();
								for (Remote_Room_info roominfo : Server.remote_room_infos) {
									if (roominfo.getServerID().equals(serverid)) {
										roomToRemove.add(roominfo);
									}
								}
								Server.remote_room_infos.removeAll(roomToRemove);
								

							}
						}
					} catch (ConcurrentModificationException e) {
					}
					
				}
			}

			
			
			try {
				sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//clear serverStatus, start the whole loop again
			
			for(String key : serverStatus.keySet()){
				System.out.println(key+serverStatus.get(key));
			}
			serverStatus.clear();
			
			
		}
		
		
		
	}
	public void newConfig(String serverid) throws IOException{
		File inputFile = new File("config.txt");
		File tempFile = new File("myTempFile.txt");

		BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

		String currentLine;

		while((currentLine = reader.readLine()) != null) {
		    if(currentLine.contains(serverid)) continue;
		    writer.write(currentLine);
		}
		writer.close(); 
		reader.close(); 
		tempFile.renameTo(inputFile);
	}
	
	
	
	
}
