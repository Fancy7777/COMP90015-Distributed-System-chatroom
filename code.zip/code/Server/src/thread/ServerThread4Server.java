package thread;

import info.Local_Room_info;
import info.Lock_info;
import info.Remote_Room_info;
import info.Server_info;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import server.Server;
import server.ServerMessages;

public class ServerThread4Server extends Thread {

	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();
	private String identity = null;
	private String serverID = null;
	private String roomID = null;
	private String address = null;
	private Integer clientPort;
	private Integer coordinationPort;

	public ServerThread4Server(Socket socket)
			throws UnsupportedEncodingException, IOException {

		this.socket = socket;
		this.out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
		//this.out = new PrintWriter(socket.getOutputStream());
		this.in = new BufferedReader(new InputStreamReader(
				socket.getInputStream(), "UTF-8"));
		System.out.println("this server:" + Server.server_id);
		System.out.println(socket);
	}

	public void run() {
		boolean flag = true;
		JSONObject message;
		try {
			while (flag) {
				JSONObject reply2ServerMessage,send2Server = new JSONObject();
				message = (JSONObject) parser.parse(in.readLine());
				System.out.println("Received"+ message);
				switch (message.get("type").toString()) {
				case "lockidentity":
					if(message.get("locked") == null){
						identity = message.get("identity").toString();
						serverID = message.get("serverid").toString();
						Boolean boolean1 = checkDuplicateIdentity(identity) && checkDuplicateLock(identity, Server.lockedIdentityList);
						if(boolean1){
							reply2ServerMessage = ServerMessages.lockIdentityReply2Server(Server.server_id, identity, boolean1);
							reply2Server(reply2ServerMessage, serverID);
							Server.lockedIdentityList.add(new Lock_info(identity, serverID));
						}else {
							reply2ServerMessage = ServerMessages.lockIdentityReply2Server(Server.server_id, identity, boolean1);
							reply2Server(reply2ServerMessage, serverID);
						}
					}else{
						boolean locked = Boolean.parseBoolean((String) message.get("locked"));
						identity = message.get("identity").toString();
						if(locked){
							Server.lockedIdentityAllowedList.add(identity);
							if(getIdentityReplyNumber(identity) == Server.remote_servers_infos.size()){
								if(!deniedListNotEmpty(identity, Server.lockedIdentityDeniedList)) {
									//add2NewRoom(identity, Server.mainhall_id);
									send2Server = ServerMessages.releaseIdentity(Server.server_id, identity);
									broadcast2Servers(send2Server);
									Server.setIsreply2Client_identity(true);
									Server.setIdentitypass(true);
									clearLockedIdentityLists(identity);
								}else{
									send2Server = ServerMessages.releaseIdentity(Server.server_id, identity);
									broadcast2Servers(send2Server);
									Server.setIsreply2Client_identity(true);
									clearLockedIdentityLists(identity);
								}
								Server.terminateServerConnection();
							}
						}else{
							Server.lockedIdentityDeniedList.add(identity);
							if(getIdentityReplyNumber(identity) == Server.remote_servers_infos.size() && 
									deniedListNotEmpty(identity, Server.lockedIdentityDeniedList)){
								send2Server = ServerMessages.releaseIdentity(Server.server_id, identity);
								broadcast2Servers(send2Server);
								Server.setIsreply2Client_identity(true);
								clearLockedIdentityLists(identity);
								Server.terminateServerConnection();
							}
						}
					}
					break;
				case "releaseidentity":
					identity = message.get("identity").toString();
					serverID = message.get("serverid").toString();
					releaseLock(identity, serverID, Server.lockedIdentityList);
					flag = false;
					break;
				case "lockroomid":
					if(message.get("locked") == null){
						roomID = message.get("roomid").toString();
						serverID = message.get("serverid").toString();
						Boolean boolean2 = checkDuplicateRoom(roomID) && checkDuplicateLock(roomID, Server.lockedRoomList);
						if(boolean2){
							reply2ServerMessage = ServerMessages.lockRoomReply2Server(Server.server_id, roomID, boolean2);
							reply2Server(reply2ServerMessage, serverID);
							Server.lockedRoomList.add(new Lock_info(roomID, serverID));
						}else {
							reply2ServerMessage = ServerMessages.lockRoomReply2Server(Server.server_id, roomID, boolean2);
							reply2Server(reply2ServerMessage, serverID);
						}
					}else{
						boolean locked = Boolean.parseBoolean((String) message.get("locked"));
						roomID = message.get("roomid").toString();
						serverID = message.get("serverid").toString();
						if(locked){
							Server.lockedRoomAllowedList.add(roomID);
							if(getRoomReplyNumber(roomID) == Server.remote_servers_infos.size()){
								if(!deniedListNotEmpty(roomID, Server.lockedRoomDeniedList)) {
									send2Server = ServerMessages.releaseRoom(Server.server_id, roomID, true);
									broadcast2Servers(send2Server);
									Server.setIsreply2Client_room(true);
									Server.setRoompass(true);
									clearLockedRoomLists(roomID);
								}else{
									send2Server = ServerMessages.releaseRoom(Server.server_id, roomID, false);
									broadcast2Servers(send2Server);
									Server.setIsreply2Client_room(true);
									clearLockedRoomLists(roomID);
								}
								Server.terminateServerConnection();
							}
						}else{
							Server.lockedRoomDeniedList.add(roomID);
							if(getRoomReplyNumber(roomID) == Server.remote_servers_infos.size() && 
									deniedListNotEmpty(roomID, Server.lockedRoomDeniedList)){
								send2Server = ServerMessages.releaseRoom(Server.server_id, roomID, false);
								broadcast2Servers(send2Server);
								Server.setIsreply2Client_room(true);
								clearLockedRoomLists(roomID);
								Server.terminateServerConnection();
							}
						}
					}
					break;
				case "releaseroomid":
					roomID = message.get("roomid").toString();
					serverID = message.get("serverid").toString();
					boolean approved = Boolean.parseBoolean((String) message.get("approved"));
					if(approved){
						for (Remote_Room_info remote_room_info : Server.remote_room_infos) {
							if (remote_room_info.getServerID()
									.equals(serverID)) {
								remote_room_info.getRoomID().add(roomID);
							}
						}
					}
					releaseLock(roomID, serverID, Server.lockedRoomList);
					flag = false;
					break;
				case "deleteroom":
					roomID = message.get("roomid").toString();
					serverID = message.get("serverid").toString();
					deleteRemoteRoom(roomID, serverID);
					flag = false;
					break;
					
					//failure handling
				case "heartbeatsignal":
					send2Server = ServerMessages.heartbeatReply();
					broadcast2Servers(send2Server);
					Server.terminateServerConnection();
					flag = false;
					break;
				
				case "heartbeatreply":	
					serverID = message.get("serverid").toString();
					for (String serverid : HeartbeatThread.serverStatus.keySet()) {
						if (serverid.equals(serverID)) {
							HeartbeatThread.serverStatus.put(serverid, HeartbeatThread.ServerOn);
						}
					}
					flag = false;
					break;
					
				case "newServer":
					serverID = message.get("serverid").toString();
					address = message.get("host").toString();
					clientPort = Integer.parseInt(message.get("clientPort").toString());
					coordinationPort = Integer.parseInt(message.get("coordinationPort").toString());
					
					Server_info serverInfo = new Server_info(serverID,address,clientPort,coordinationPort);
					Server.remote_servers_infos.add(serverInfo);
					
					ArrayList<String> roomidArrayList = new ArrayList<String>();
					roomidArrayList.add("MainHall-"+ serverID);
					Server.remote_room_infos.add(new Remote_Room_info(roomidArrayList, serverID));
				}
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
				in.close();
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void clearLockedRoomLists(String roomID) {
		Server.lockedRoomAllowedList.remove(roomID);
		Server.lockedRoomDeniedList.remove(roomID);
	}

	public void deleteRemoteRoom(String roomID, String serverID) {
		for (Remote_Room_info remote_room_info : Server.remote_room_infos) {
			if (remote_room_info.getServerID().equals(serverID)) {
				remote_room_info.getRoomID().remove(roomID);
			}
		}
		
	}

	public void releaseLock(String item, String serverid, ArrayList<Lock_info> lockedlist) {
		for(int i = lockedlist.size(); i > 0; i--){
			if(item.equals(lockedlist.get(i-1).getIdentity()) && 
					serverid.equals(lockedlist.get(i-1).getServerID())){
				lockedlist.remove(lockedlist.get(i-1));
			} 
		}
	}

	public void reply2Server(JSONObject jsonObject, String serverid)
			throws UnknownHostException, IOException {
		if (!server.Server.init_server)
			server.Server.initialServerConnection();
		String replymessage = jsonObject.toJSONString();
		for (int i = 0; i < Server.remote_servers_infos.size(); i++) {
			if (Server.remote_servers_infos.get(i).getServer_id()
					.equals(serverid)) {
				Socket socket4Reply = Server.socket4Server.get(i);
				PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(socket4Reply.getOutputStream(), StandardCharsets.UTF_8), true);
				//PrintWriter printWriter = new PrintWriter(socket4Reply.getOutputStream());
				printWriter.println(replymessage);
				printWriter.flush();
			}
		}
	}
	
	public boolean checkDuplicateIdentity(String identity) {
		for (Local_Room_info local_room_info : server.Server.local_room_infos) {
			if (local_room_info.getRoom_content().contains(identity)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean checkDuplicateRoom(String roomID) {
		for (Local_Room_info local_room_info : server.Server.local_room_infos) {
			if (local_room_info.getRoom_id().contains(roomID)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean checkDuplicateLock(String identity, ArrayList<Lock_info> serverLock_info){
		for(Lock_info lock_info : serverLock_info)
			if(lock_info.getIdentity().equals(identity))
				return false;
		return true;
	}
	
	public static void broadcast2Servers(JSONObject jsonObject) throws IOException
	{
		String message = jsonObject.toJSONString();
		if (!Server.init_server)
			try{
			Server.initialServerConnection();
			}
			catch(ConnectException e){}
		for(Socket socket : Server.socket4Server){
			//PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
			PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
			printWriter.println(message);
			printWriter.flush();
		}
	}
	
	private boolean deniedListNotEmpty(String identity, ArrayList<String> lockedDeniedList) {
		for(String item : lockedDeniedList){
			if(item.equals(identity))
				return true;
		}
		return false;
	}

	private void clearLockedIdentityLists(String identity) {
		Server.lockedIdentityAllowedList.remove(identity);
		Server.lockedIdentityDeniedList.remove(identity);
	}
	
	private int getIdentityReplyNumber(String item) {
		int count = 0;
		for (String each : Server.lockedIdentityAllowedList) {
			if (each.equals(item))
				count++;
		}
		for(String each : Server.lockedIdentityDeniedList) {
			if (each.equals(item))
				count++;
		}
		return count;
	}
	
	private int getRoomReplyNumber(String item) {
		int count = 0;
		for (String each : Server.lockedRoomAllowedList) {
			if (each.equals(item))
				count++;
		}
		for(String each : Server.lockedRoomDeniedList) {
			if (each.equals(item))
				count++;
		}
		return count;
	}
	
}
