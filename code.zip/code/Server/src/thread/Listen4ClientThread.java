package thread;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import server.Server;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.TrustManagerFactory;
public class Listen4ClientThread extends Thread{

	private int clients_port;
	private static final String SERVER_KEY_STORE_PASSWORD       = "123456";
	private static final String SERVER_TRUST_KEY_STORE_PASSWORD = "123456";

	private SSLServerSocket     serverSocket;
	public Listen4ClientThread(int clients_port){
		this.clients_port = clients_port;
	}
	
	@SuppressWarnings("resource")
	public void run() {
		System.out.println("listenning for client ...");
		ServerSocket server = null;
		try {
			SSLContext ctx = SSLContext.getInstance("SSL");
			
			//Using SunX509 for encription
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            
            
            KeyStore ks = KeyStore.getInstance("JKS");
            KeyStore tks = KeyStore.getInstance("JKS");

            //load certificates
            ks.load(new FileInputStream("data/kserver.keystore"), SERVER_KEY_STORE_PASSWORD.toCharArray());
            tks.load(new FileInputStream("data/tserver.keystore"), SERVER_TRUST_KEY_STORE_PASSWORD.toCharArray());

            //inintial encryption
            kmf.init(ks, SERVER_KEY_STORE_PASSWORD.toCharArray());
            tmf.init(tks);
           
            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            serverSocket = (SSLServerSocket) ctx.getServerSocketFactory().createServerSocket(clients_port);
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch(Exception e){
			e.printStackTrace();
		}
		while (true) {
			try {
				Socket socket = serverSocket.accept();
				ServerThread4Client serverThread4client = new ServerThread4Client(
						socket);
				Server.client_thread_list.add(serverThread4client);
				serverThread4client.start();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
	
}
