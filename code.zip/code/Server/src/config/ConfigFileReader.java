package config;

import info.Server_info;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ConfigFileReader {

	String serverid;
	int clients_port;
	int servers_port;
	String hostAddress;
	ArrayList<Server_info> remoteServer_infos = new ArrayList<>();

	public ConfigFileReader(String configPath, String localServerID) throws FileNotFoundException{
		File filename = new File(configPath);
		try {
			InputStreamReader reader = new InputStreamReader(
					new FileInputStream(filename));
			@SuppressWarnings("resource")
			BufferedReader br = new BufferedReader(reader);
			String line = null;
			line = br.readLine();
			while (line != null) {
				ConfigFileReadLine configFileReadLine = new ConfigFileReadLine(
						line);
				if (configFileReadLine.getServerid().equals(localServerID)) {
					serverid = configFileReadLine.getServerid();
					clients_port = configFileReadLine.getClients_port();
					servers_port = configFileReadLine.getCoordination_port();
					hostAddress = configFileReadLine.getServer_address();
				} 
				else {
					remoteServer_infos.add(new Server_info(configFileReadLine
							.getServerid(), configFileReadLine
							.getServer_address(), configFileReadLine
							.getClients_port(), configFileReadLine
							.getCoordination_port()));
				}
				//System.out.println(line);
				line = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public ArrayList<Server_info> getRemoteServer_infos() {
		return remoteServer_infos;
	}

	public String getServerid() {
		return serverid;
	}

	public int getClients_port() {
		return clients_port;
	}

	public int getServers_port() {
		return servers_port;
	}
	
	public String getHostAddress(){
		return hostAddress;
	}

}
