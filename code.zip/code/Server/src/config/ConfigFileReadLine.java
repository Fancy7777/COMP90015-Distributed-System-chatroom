package config;

public class ConfigFileReadLine {

	String serverid;
	String server_address;
	int clients_port;
	int coordination_port;
	
	public ConfigFileReadLine(String line) {
		String[] portion = line.split("\t");
		this.setServerid(portion[0]);
		this.setServer_address(portion[1]);
		this.setClients_port(Integer.parseInt(portion[2]));
		this.setCoordination_port(Integer.parseInt(portion[3]));
	}

	public String getServerid() {
		return serverid;
	}

	public void setServerid(String serverid) {
		this.serverid = serverid;
	}

	public String getServer_address() {
		return server_address;
	}

	public void setServer_address(String server_address) {
		this.server_address = server_address;
	}

	public int getClients_port() {
		return clients_port;
	}

	public void setClients_port(int clients_port) {
		this.clients_port = clients_port;
	}

	public int getCoordination_port() {
		return coordination_port;
	}

	public void setCoordination_port(int coordination_port) {
		this.coordination_port = coordination_port;
	}
}
