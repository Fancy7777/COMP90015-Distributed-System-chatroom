package server;

import info.Local_Room_info;
import info.Lock_info;
import info.Remote_Room_info;
import info.Server_info;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;
import thread.HeartbeatThread;
import thread.Listen4ClientThread;
import thread.Listen4ServerThread;
import thread.ServerThread4Client;
import thread.ServerThread4Server;
import config.ConfigFileReader;

public class Server {

	public static ArrayList<ServerThread4Client> client_thread_list = new ArrayList<>();
	public static ArrayList<Socket> socket4Server = new ArrayList<Socket>();
	public static Socket socket4CentralServer;

	public static ArrayList<Server_info> remote_servers_infos = new ArrayList<Server_info>();
	public static ArrayList<Local_Room_info> local_room_infos = new ArrayList<>();
	public static ArrayList<Remote_Room_info> remote_room_infos = new ArrayList<>();

	public static ArrayList<Lock_info> lockedIdentityList = new ArrayList<>();
	public static ArrayList<String> lockedIdentityAllowedList = new ArrayList<String>();
	public static ArrayList<String> lockedIdentityDeniedList = new ArrayList<String>();

	public static ArrayList<Lock_info> lockedRoomList = new ArrayList<>();
	public static ArrayList<String> lockedRoomAllowedList = new ArrayList<String>();
	public static ArrayList<String> lockedRoomDeniedList = new ArrayList<String>();

	public static boolean isreply2Client_identity = false;
	public static boolean isreply2Client_room = false;
	public static boolean identitypass = false;
	public static boolean roompass = false;

	
	public static String server_id;
	static int clients_port;
	static int servers_port;
	public static String mainhall_id;

	public static boolean init_server = false;
	public static boolean init_central_server = false;
	
	private static int port4CentralServer = 3333;
	private static String address4CentralServer = "localhost";
	private static final String CLIENT_KEY_STORE_PASSWORD       = "123456";
    private static final String CLIENT_TRUST_KEY_STORE_PASSWORD = "123456";

	public static void main(String[] args) throws UnknownHostException, IOException, ParseException {

		// get the command line values and parse server config files
		ComLineValues comLineValues = new ComLineValues(args);

		// read config file for later use. normal getters for current server
		// information
		// remote_room_info stores other servers' info
		ConfigFileReader reader = new ConfigFileReader(comLineValues.getServerConf(), comLineValues.getServerId());
		


		// scalability
		if(reader.getServerid()!=null && comLineValues.getHost()!=null){
			System.err.println("Duplication server id!!");
			System.exit(0);
		}
		
		else if (reader.getServerid() != null) {

			server_id = reader.getServerid();
			mainhall_id = "MainHall-" + server_id;
			clients_port = reader.getClients_port();
			servers_port = reader.getServers_port();
			remote_servers_infos = reader.getRemoteServer_infos();
		}
		 
		else {
			System.out.println("This server info does not exist in config.txt");
			System.out.println("A new server is created and the corresponding info is adding to the config.txt");
			// write new server into the config file
			Writer output = new BufferedWriter(new FileWriter(comLineValues.getServerConf(), true));
			output.append("\n" + comLineValues.getServerId() + "\t" + comLineValues.getHost() + "\t"
					+ comLineValues.getPort() + "\t" + comLineValues.getCPort());
			output.close();

			// read config file the second time
			ConfigFileReader reader2 = new ConfigFileReader(comLineValues.getServerConf(), comLineValues.getServerId());

			server_id = reader2.getServerid();
			mainhall_id = "MainHall-" + server_id;
			clients_port = reader2.getClients_port();
			servers_port = reader2.getServers_port();
			remote_servers_infos = reader2.getRemoteServer_infos();

			// create new json Object sent to other servers
			// to remind them change what is been saved into their data
			// structure
			JSONObject updateNewServerMsg = new JSONObject();
			updateNewServerMsg = ServerMessages.newServerInfo(comLineValues.getServerId(), comLineValues.getHost(),
					comLineValues.getPort(), comLineValues.getCPort());

			// broadcast this message to every other servers
			try {
				ServerThread4Server.broadcast2Servers(updateNewServerMsg);
			} catch (ConnectException e) {

			}

		}
		for (Server_info server_info : remote_servers_infos) {
			System.out.println(server_info.getServer_id());
			ArrayList<String> roomidArrayList = new ArrayList<String>();
			roomidArrayList.add("MainHall-" + server_info.getServer_id());
			remote_room_infos.add(new Remote_Room_info(roomidArrayList, server_info.getServer_id()));
			// failure handling
			
		}

		local_room_infos.add(new Local_Room_info(
				mainhall_id, "", new ArrayList<String>(), new HashMap<String,Integer>()));
		
		try{
			runThread();}
		catch(Exception e){
			terminateServerConnection();
		}
	}

	// open two threads to listen both two ports
	public static void runThread() {
		Listen4ClientThread listen4ClientThread = new Listen4ClientThread(clients_port);
		listen4ClientThread.start();
		Listen4ServerThread listen4ServerThread = new Listen4ServerThread(servers_port);
		listen4ServerThread.start();
		
		HeartbeatThread heartbeatThread = new HeartbeatThread();
		heartbeatThread.start();
		
	}

	public static void initialServerConnection() throws UnknownHostException, IOException {
		System.out.println("initialing connections....");
		for (Server_info server_info : remote_servers_infos) {
			try{
				SSLContext ctx = SSLContext.getInstance("SSL");

	            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
	            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");

	            KeyStore ks = KeyStore.getInstance("JKS");
	            KeyStore tks = KeyStore.getInstance("JKS");

	            ks.load(new FileInputStream("data/kclient.keystore"), CLIENT_KEY_STORE_PASSWORD.toCharArray());
	            tks.load(new FileInputStream("data/tclient.keystore"), CLIENT_TRUST_KEY_STORE_PASSWORD.toCharArray());

	            kmf.init(ks, CLIENT_KEY_STORE_PASSWORD.toCharArray());
	            tmf.init(tks);

	            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

	            SSLSocket socket = (SSLSocket) ctx.getSocketFactory().createSocket(server_info.getServer_address(), server_info.getServers_port());
	            try{
	            	socket.connect(new InetSocketAddress(server_info.getServer_address(),server_info.getServers_port()),200);
	            	socket4Server.add(socket);
	            }catch(IOException e){
	            	System.out.println("-------------------");
	            	socket4Server.remove(socket);
	            }
	            
	            socket4Server.add(socket);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
		}
		init_server = true;
	}
	
	public static void initialCentralServerConnection() throws UnknownHostException, IOException {
		try{
			SSLContext ctx = SSLContext.getInstance("SSL");

            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");

            KeyStore ks = KeyStore.getInstance("JKS");
            KeyStore tks = KeyStore.getInstance("JKS");

            ks.load(new FileInputStream("data/kclient.keystore"), CLIENT_KEY_STORE_PASSWORD.toCharArray());
            tks.load(new FileInputStream("data/tclient.keystore"), CLIENT_TRUST_KEY_STORE_PASSWORD.toCharArray());

            kmf.init(ks, CLIENT_KEY_STORE_PASSWORD.toCharArray());
            tmf.init(tks);

            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            socket4CentralServer = (SSLSocket) ctx.getSocketFactory().createSocket(address4CentralServer, port4CentralServer);
            init_central_server = true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
	public static void terminateServerConnection() throws IOException {
		for (Socket socket : socket4Server)
			socket.close();
		socket4Server.clear();
		init_server = false;
	}
	public static void terminateCentralServerConnection() throws IOException {
		socket4CentralServer.close();
		init_central_server = false;
	}

	public static boolean isIsreply2Client_identity() {
		return isreply2Client_identity;
	}

	public static void setIsreply2Client_identity(boolean isreply2Client_identity) {
		Server.isreply2Client_identity = isreply2Client_identity;
	}

	public static boolean isIsreply2Client_room() {
		return isreply2Client_room;
	}

	public static void setIsreply2Client_room(boolean isreply2Client_room) {
		Server.isreply2Client_room = isreply2Client_room;
	}

	public static boolean isIdentitypass() {
		return identitypass;
	}

	public static void setIdentitypass(boolean identitypass) {
		Server.identitypass = identitypass;
	}

	public static boolean isRoompass() {
		return roompass;
	}

	public static void setRoompass(boolean roompass) {
		Server.roompass = roompass;
	}
}
