package server;

import java.util.ArrayList;

import org.json.simple.JSONObject;

public class ServerMessages {
	
	@SuppressWarnings("unchecked")
	public static JSONObject lockIdentityRequest(String serverID, String identity) {
		JSONObject lockIdentityRequest = new JSONObject();
		lockIdentityRequest.put("type", "lockidentity");
		lockIdentityRequest.put("serverid", serverID);
		lockIdentityRequest.put("identity", identity);
		return lockIdentityRequest;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject lockIdentityReply2Server(String serverID, String identity, Boolean boolean1) {
		String booleanString = boolean1.toString();
		JSONObject lockIdentityReply = new JSONObject();
		lockIdentityReply.put("type", "lockidentity");
		lockIdentityReply.put("serverid", serverID);
		lockIdentityReply.put("identity", identity);
		lockIdentityReply.put("locked", booleanString);
		return lockIdentityReply;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject lockIdentityReply2Client(Boolean boolean1) {
		String booleanString = boolean1.toString();
		JSONObject lockIdentityReply = new JSONObject();
		lockIdentityReply.put("type", "newidentity");
		lockIdentityReply.put("approved", booleanString);
		return lockIdentityReply;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject releaseIdentity(String serverID, String identity) {
		JSONObject releaseIdentity = new JSONObject();
		releaseIdentity.put("type", "releaseidentity");
		releaseIdentity.put("serverid", serverID);
		releaseIdentity.put("identity", identity);
		return releaseIdentity;
	}

	@SuppressWarnings("unchecked")
	public static JSONObject roomChangeMessage(String identity, String former, String roomID) {
		JSONObject roomChangeMessage = new JSONObject();
		roomChangeMessage.put("type", "roomchange");
		roomChangeMessage.put("identity", identity);
		roomChangeMessage.put("former", former);
		roomChangeMessage.put("roomid", roomID);
		return roomChangeMessage;
	}

	@SuppressWarnings("unchecked")
	public static JSONObject getListReply(ArrayList<JSONObject> roomlist) {
		JSONObject getListReply = new JSONObject();
		getListReply.put("type", "roomlist");
		getListReply.put("rooms", roomlist);
		return getListReply;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject getWhoReply(String roomID, ArrayList<JSONObject> roomlist, String owner, ArrayList<JSONObject> index) {
		JSONObject getWhoReply = new JSONObject();
		getWhoReply.put("type", "roomcontents");
		getWhoReply.put("roomid", roomID);
		getWhoReply.put("identities", roomlist);
		getWhoReply.put("owner", owner);
		getWhoReply.put("indexs", index);
		return getWhoReply;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject newServerIntroduction(String serverName){
		JSONObject message = new JSONObject();
		message.put("newserver", serverName);
		return message;
	}
	
	public static JSONObject newServerReply(String serverName, Boolean boolean1){
		JSONObject message = new JSONObject();
		message.put("newserver", serverName);
		message.put("approved", boolean1);
		return message;
	}
	
	public static JSONObject loginReply(Boolean boolean1){
		String booleanString = boolean1.toString();
		JSONObject message = new JSONObject();
		message.put("type", "login");
		message.put("approved", booleanString);
		return message;
	}
	@SuppressWarnings("unchecked")
	public static JSONObject lockRoomRequest(String serverID, String roomid) {
		JSONObject lockRoomRequest = new JSONObject();
		lockRoomRequest.put("type", "lockroomid");
		lockRoomRequest.put("serverid", serverID);
		lockRoomRequest.put("roomid", roomid);
		return lockRoomRequest;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject lockRoomReply2Server(String serverID, String roomID, Boolean boolean1) {
		String booleanString = boolean1.toString();
		JSONObject lockRoomReply2Server = new JSONObject();
		lockRoomReply2Server.put("type", "lockroomid");
		lockRoomReply2Server.put("serverid", serverID);
		lockRoomReply2Server.put("roomid", roomID);
		lockRoomReply2Server.put("locked", booleanString);
		return lockRoomReply2Server;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject lockRoomReply2Client(String roomID, Boolean boolean1) {
		String booleanString = boolean1.toString();
		JSONObject lockRoomReply2Client = new JSONObject();
		lockRoomReply2Client.put("type", "createroom");
		lockRoomReply2Client.put("approved", booleanString);
		lockRoomReply2Client.put("roomid", roomID);
		return lockRoomReply2Client;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject releaseRoom(String serverID, String identity, Boolean boolean1) {
		String booleanString = boolean1.toString();
		JSONObject releaseRoom = new JSONObject();
		releaseRoom.put("type", "releaseroomid");
		releaseRoom.put("serverid", serverID);
		releaseRoom.put("roomid", identity);
		releaseRoom.put("approved", booleanString);
		return releaseRoom;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject routeMessageReply(String roomID, String host, int port) {
		JSONObject routeMessageReply = new JSONObject();
		routeMessageReply.put("type", "route");
		routeMessageReply.put("roomid", roomID);
		routeMessageReply.put("host", host);
		routeMessageReply.put("port", Long.toString(port));
		return routeMessageReply;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject moveJoinRequest(String former, String roomID, String identity) {
		JSONObject moveJoinRequest = new JSONObject();
		moveJoinRequest.put("type", "movejoin");
		moveJoinRequest.put("former", former);
		moveJoinRequest.put("roomid", roomID);
		moveJoinRequest.put("identity", identity);
		return moveJoinRequest;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject moveJoinReply(Boolean boolean1, String serverID) {
		String booleanString = boolean1.toString();
		JSONObject moveJoinReply = new JSONObject();
		moveJoinReply.put("type", "serverchange");
		moveJoinReply.put("approved", booleanString);
		moveJoinReply.put("serverid", serverID);
		return moveJoinReply;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject deleteRoomReply(String roomID, Boolean boolean1) {
		String booleanString = boolean1.toString();
		JSONObject deleteRoomReply = new JSONObject();
		deleteRoomReply.put("type", "deleteroom");
		deleteRoomReply.put("roomid", roomID);
		deleteRoomReply.put("approved", booleanString);
		return deleteRoomReply;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject deleteRoomInformation(String serverID, String roomID) {
		JSONObject deleteRoomInformation = new JSONObject();
		deleteRoomInformation.put("type", "deleteroom");
		deleteRoomInformation.put("serverid", serverID);
		deleteRoomInformation.put("roomid", roomID);
		return deleteRoomInformation;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject getMessage(String content, String identity) {
		JSONObject message = new JSONObject();
		message.put("type", "message");
		message.put("content", content);
		message.put("identity", identity);
		return message;		
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject NewServerIntroduction(String serverName){
		JSONObject message = new JSONObject();
		message.put("newserver", serverName);
		return message;
	}
	
	//failure handling
	public static JSONObject heartbeatSignal() {
		JSONObject hbSignal = new JSONObject();
		hbSignal.put("type", "heartbeatsignal");
		hbSignal.put("serverid", Server.server_id);
		return hbSignal;
	}
	
	public static JSONObject heartbeatReply() {
		JSONObject hbReply = new JSONObject();
		hbReply.put("type", "heartbeatreply");
		hbReply.put("serverid", Server.server_id);
		return hbReply;
	}
	
	//scalability
	public static JSONObject newServerInfo(String serverid, String address, 
			Integer client_port, Integer coordination_port){
		JSONObject serverInfo = new JSONObject();
		serverInfo.put("type", "newServer");
		serverInfo.put("serverid", serverid);
		serverInfo.put("host", address);
		serverInfo.put("clientPort", client_port);
		serverInfo.put("coordinationPort", coordination_port);
		return serverInfo;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject getLoginReply(Boolean boolean1) {
		JSONObject loginReply = new JSONObject();
		String booleanString = boolean1.toString();
		loginReply.put("type", "loginReply");
		loginReply.put("approved", booleanString);
		return loginReply;
	}

}
