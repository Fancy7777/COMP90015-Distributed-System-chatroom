package server;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class ComLineValues {
	@Option(name = "-n", usage = "server id")
	private String server_id;

	@Option(name = "-l", usage = "path of servers configuration")
	private String ConfigPath;			
	
	@Option(name = "-h", usage = "Server host address")
	private String host;
	
	@Option(name = "-p", usage = "Server port number")
	private int port;
	
	//scalability
	@Option(name = "-c", usage = "Coordination port number")
	private int c_port;

	public ComLineValues(String... args) {
		CmdLineParser parser = new CmdLineParser(this);
		try {
			parser.parseArgument(args);
		} catch (CmdLineException e) {
			System.err.println(e.getMessage());
			parser.printUsage(System.err);
		}

	}
	
	public String getServerId(){
		return server_id;
	}
	
	public String getServerConf(){
		return ConfigPath;
	}
	
	public String getHost(){
		return host;
	}
	
	public int getPort(){
		return port;
	}
	
	public int getCPort(){
		return c_port;
	}
}
