package info;

import java.util.ArrayList;
import java.util.HashMap;

public class Local_Room_info {
	
	private String room_id;
	private String owner;
	private ArrayList<String> room_content = new ArrayList<String>();
	private HashMap<String,Integer> IdentityWithIndex =  new HashMap<String,Integer>(); 
	
	public Local_Room_info(String room_id, String owner, ArrayList<String> room_content, HashMap<String,Integer> IdentityWithIndex) {
		this.room_id = room_id;
		this.owner = owner;
		this.room_content = room_content;
		this.IdentityWithIndex = IdentityWithIndex;
	}

	public HashMap<String,Integer> getIdentityWithIndex(){
		return IdentityWithIndex;
	}

	public String getRoom_id() {
		return room_id;
	}

	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public ArrayList<String> getRoom_content() {
		return room_content;
	}

	public void setRoom_content(ArrayList<String> room_content) {
		this.room_content = room_content;
	}
	
	
}
