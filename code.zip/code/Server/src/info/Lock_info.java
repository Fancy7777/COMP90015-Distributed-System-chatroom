package info;

public class Lock_info {

	private String identity;
	private String serverID;
	
	public Lock_info(String identity, String serverID){
		this.identity = identity;
		this.serverID = serverID;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getServerID() {
		return serverID;
	}

	public void setServerID(String serverID) {
		this.serverID = serverID;
	}
}
