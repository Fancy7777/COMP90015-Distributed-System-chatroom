package info;

public class Server_info {

	private String server_id;
	private String server_address;
	private int clients_port;
	private int servers_port;
	
	public Server_info(String server_id, String server_address, int clients_port, int servers_port) {
		// TODO Auto-generated constructor stub
		this.server_id = server_id;
		this.server_address = server_address;
		this.clients_port = clients_port;
		this.servers_port = servers_port;
	}

	public String getServer_id() {
		return server_id;
	}

	public void setServer_id(String server_id) {
		this.server_id = server_id;
	}

	public String getServer_address() {
		return server_address;
	}

	public void setServer_address(String server_address) {
		this.server_address = server_address;
	}

	public int getClients_port() {
		return clients_port;
	}

	public void setClients_port(int clients_port) {
		this.clients_port = clients_port;
	}

	public int getServers_port() {
		return servers_port;
	}

	public void setServers_port(int servers_port) {
		this.servers_port = servers_port;
	}

}