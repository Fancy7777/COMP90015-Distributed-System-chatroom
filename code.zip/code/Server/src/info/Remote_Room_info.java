package info;

import java.util.ArrayList;

public class Remote_Room_info {
	
	private ArrayList<String> roomID;
	private String serverID;
	
	public Remote_Room_info(ArrayList<String> roomID, String serverID){
		this.roomID = roomID;
		this.serverID = serverID;
	}

	public ArrayList<String> getRoomID() {
		return roomID;
	}

	public void setRoomID(ArrayList<String> roomID) {
		this.roomID = roomID;
	}

	public String getServerID() {
		return serverID;
	}

	public void setServerID(String serverID) {
		this.serverID = serverID;
	}

	
}
