package au.edu.unimelb.tcp.client_model;

import java.util.List;

import javax.swing.AbstractListModel;

import au.edu.unimelb.tcp.client.Room;

public class RoomListModel extends AbstractListModel{
	
private List<Room> rooms;
	
	public RoomListModel(List<Room> rooms) {
		this.rooms = rooms;
	}
	
	public void addElement(Object object) {
		if (rooms.contains(object)) {
			return;
		}
		int index = rooms.size();
		rooms.add((Room)object);
		fireIntervalAdded(this, index, index);
	}
	
	public boolean removeElement(Object object) {
		int index = rooms.indexOf(object);
		if (index >= 0) {
			fireIntervalRemoved(this, index, index);
		}
		return rooms.remove(object);
	}
	
	public void clear(){
		rooms.clear();
	}
	
	public Object getElementAt(int i) {
		// TODO Auto-generated method stub
		return rooms.get(i);
	}

	public int getSize() {
		// TODO Auto-generated method stub
		return rooms.size();
	}
	
	public List<Room> getRoommateList(){
		return rooms;
	}
	
}
