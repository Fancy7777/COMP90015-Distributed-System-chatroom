package au.edu.unimelb.tcp.client_gui;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;

import javax.swing.*;
import javax.swing.border.*;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import au.edu.unimelb.tcp.client.ClientMessages;
import au.edu.unimelb.tcp.client.MessageReceiveThread;
import au.edu.unimelb.tcp.client.MessageSendThread;

@SuppressWarnings("serial")
public class LoginFrame extends JFrame {

	private JTextField idTxt;
	private JPasswordField pwdFld;
	private MessageSendThread msgSendThread;
	private MessageReceiveThread msgReceiveThread;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();
	
	public LoginFrame(MessageSendThread msgSendThread, MessageReceiveThread msgReceiveThread){
		this.init();
		setVisible(true);
		this.msgSendThread = msgSendThread;
		this.msgReceiveThread = msgReceiveThread;
		this.in = msgReceiveThread.getIn();
	}
	
	public void init(){
		this.setTitle("Chatting-Room Login");
		this.setSize(330, 230);
		//set the frame to the middle of the screen
		int x = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((x - this.getWidth()) / 2, (y-this.getHeight())/ 2);
		this.setResizable(false);
		
		//set logo to the north of the frame
		Icon icon = new ImageIcon("images/logo1.png");
		JLabel label = new JLabel(icon);
		this.add(label, BorderLayout.NORTH);

		//login panel
		JPanel mainPanel = new JPanel();
		Border border = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
		mainPanel.setBorder(BorderFactory.createTitledBorder(border, "please enter login information", TitledBorder.CENTER,TitledBorder.TOP));
		this.add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(null);
		
		JLabel nameLbl = new JLabel("username:");
		nameLbl.setBounds(40, 30, 70, 22);
		mainPanel.add(nameLbl);
		idTxt = new JTextField();
		idTxt.setBounds(115, 30, 150, 22);
		idTxt.requestFocusInWindow();//get focus
		mainPanel.add(idTxt);
		
		JLabel pwdLbl = new JLabel("password:");
		pwdLbl.setBounds(40, 60, 70, 22);
		mainPanel.add(pwdLbl);
		pwdFld = new JPasswordField();
		pwdFld.setBounds(115, 60, 150, 22);
		mainPanel.add(pwdFld);
		
		//set buttons to the south of the frame
		JPanel btnPanel = new JPanel();
		this.add(btnPanel, BorderLayout.SOUTH);
		btnPanel.setLayout(new BorderLayout());
		btnPanel.setBorder(new EmptyBorder(2, 8, 4, 8)); 

		JButton registeBtn = new JButton("register");
		btnPanel.add(registeBtn, BorderLayout.WEST);
		JButton submitBtn = new JButton("login");
		btnPanel.add(submitBtn, BorderLayout.EAST);
		
		//close the frame
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) {
				//send a guest quit message
				LoginFrame.this.dispose();
			}
		});
		
		//register button 
		registeBtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new RegisterFrame();  //open register frame
			}
		});
		
		//login button
		submitBtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				try {
					login();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}

	/** login
	 * @throws IOException 
	 * @throws ParseException */
	@SuppressWarnings("unchecked")
	private void login() throws IOException, ParseException {
		if (idTxt.getText().length() == 0 
				|| pwdFld.getPassword().length == 0) {
			JOptionPane.showMessageDialog(LoginFrame.this, 
					"username and password is required",
					"error!",JOptionPane.ERROR_MESSAGE);
			idTxt.requestFocusInWindow();
			return;
		}
		
		JSONObject sendToServer = new JSONObject();
		sendToServer = ClientMessages.getLoginRequest(idTxt.getText(), String.valueOf(pwdFld.getPassword()));
		msgSendThread.send(sendToServer);
		
		JSONObject message = (JSONObject) parser.parse(in.readLine());
		System.out.println(message);
		boolean loginApproved = Boolean.parseBoolean((String) message.get("approved"));
		if(loginApproved){
			LoginFrame.this.dispose();
			new SetInfoFrame(msgSendThread, msgReceiveThread);
		}else{
			JOptionPane.showMessageDialog(LoginFrame.this, 
						"Cannot log in. Please check your account information",
						"Fail to log in",JOptionPane.ERROR_MESSAGE);
			idTxt.requestFocusInWindow();
		}
	}
}