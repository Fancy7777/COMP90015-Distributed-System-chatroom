package au.edu.unimelb.tcp.client_gui;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import au.edu.unimelb.tcp.client.ClientMessages;
import au.edu.unimelb.tcp.client.MessageReceiveThread;
import au.edu.unimelb.tcp.client.MessageSendThread;

public class CreateRoomFrame extends JFrame{

	private JTextField roomID;
	private MessageSendThread msgSendThread;
	private MessageReceiveThread msgReceiveThread;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();
	
	public CreateRoomFrame(MessageSendThread msgSendThread, MessageReceiveThread msgReceiveThread){
		this.init();
		setVisible(true);
		this.msgSendThread = msgSendThread;
		this.msgReceiveThread = msgReceiveThread;
		this.in = msgReceiveThread.getIn();
	}
	
	public void init(){
		this.setTitle("Set room ID");
		this.setSize(330, 180);
		//set the frame to the middle of the screen
		int x = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((x - this.getWidth()) / 2, (y-this.getHeight())/ 2);
		this.setResizable(false);
		
		getContentPane().setLayout(null);
		setResizable(false);

		Icon icon = new ImageIcon("images/logo1.png");
		JLabel labelIcon = new JLabel(icon);
		labelIcon.setBounds(0, 0, 324, 47);
		getContentPane().add(labelIcon);
		
		JLabel label = new JLabel("room ID:");
		label.setBounds(50, 60, 60, 20);
		getContentPane().add(label);
		
		roomID = new JTextField(); //�ǳ�
		roomID.setBounds(110, 60, 130, 20);
		getContentPane().add(roomID);
		
		
		//submit button
		JButton ok = new JButton("Sumbit");
		ok.setBounds(170, 100, 75, 25);
		getContentPane().add(ok);

		JButton cancel = new JButton("Cancel");
		cancel.setBounds(80, 100, 75, 25);
		getContentPane().add(cancel);
		
		//listen on cancel button
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent event) {
				CreateRoomFrame.this.dispose();
			}
		});
		//when closing window
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) {
				CreateRoomFrame.this.dispose();
			}
		});
			
		//listen on sumbit button
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				JSONObject sendToServer = new JSONObject();
				sendToServer = ClientMessages.getCreateRoomRequest(roomID.getText());
				try {
					msgSendThread.send(sendToServer);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				CreateRoomFrame.this.dispose();
			}
		});
	}
}
