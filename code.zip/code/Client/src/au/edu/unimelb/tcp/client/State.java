package au.edu.unimelb.tcp.client;

import javax.swing.ImageIcon;

public class State {

	private String identity;
	private String roomId;
	private int imageIndex;
	
	public State(String identity, String roomId, int imageIndex) {
		this.identity = identity;
		this.roomId = roomId;
		this.imageIndex = imageIndex;
	}
	
	public synchronized String getRoomId() {
		return roomId;
	}
	public synchronized void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	
	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getIdentity() {
		return identity;
	}

	public int getImageIndex() {
		return imageIndex;
	}

	public void setImageIndex(int imageIndex) {
		this.imageIndex = imageIndex;
	}
	
	public ImageIcon getHeadIcon() {
		ImageIcon image = new ImageIcon("images/32/" + imageIndex + ".png");
		return image;
	}
}
