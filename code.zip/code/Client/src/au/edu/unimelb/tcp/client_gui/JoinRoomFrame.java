package au.edu.unimelb.tcp.client_gui;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;

import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import au.edu.unimelb.tcp.client.ClientMessages;
import au.edu.unimelb.tcp.client.MessageReceiveThread;
import au.edu.unimelb.tcp.client.MessageSendThread;
import au.edu.unimelb.tcp.client_model.MyCellRenderer4Room;
import au.edu.unimelb.tcp.client_model.RoomListModel;

public class JoinRoomFrame extends JFrame{

	JComboBox comboBox=new JComboBox();  
	private MessageSendThread msgSendThread;
	private MessageReceiveThread msgReceiveThread;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();
	
	public JoinRoomFrame(MessageSendThread msgSendThread, MessageReceiveThread msgReceiveThread) {
		// TODO Auto-generated constructor stub
		this.init();
		setVisible(true);
		this.msgSendThread = msgSendThread;
		this.msgReceiveThread = msgReceiveThread;
		this.in = msgReceiveThread.getIn();
	}
	
	public void init(){
		this.setTitle("Join Room");
		this.setSize(330, 180);
		//set the frame to the middle of the screen
		int x = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((x - this.getWidth()) / 2, (y-this.getHeight())/ 2);
		this.setResizable(false);
		
		getContentPane().setLayout(null);
		setResizable(false);

		Icon icon = new ImageIcon("images/logo1.png");
		JLabel labelIcon = new JLabel(icon);
		labelIcon.setBounds(0, 0, 324, 47);
		getContentPane().add(labelIcon);
		
		JLabel label = new JLabel("Going to:");
		label.setBounds(65, 60, 60, 20);
		getContentPane().add(label);
		

		initComboBox();
		comboBox.setBounds(130, 60, 130, 20);
		getContentPane().add(comboBox);
	
		//submit button
		JButton ok = new JButton("Sumbit");
		ok.setBounds(170, 100, 75, 25);
		getContentPane().add(ok);

		JButton cancel = new JButton("Cancel");
		cancel.setBounds(80, 100, 75, 25);
		getContentPane().add(cancel);
		
		//listen on cancel button
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent event) {
				JoinRoomFrame.this.dispose();
			}
		});
		//when closing window
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) {
				JoinRoomFrame.this.dispose();
			}
		});
			
		//listen on sumbit button
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				JSONObject sendToServer = new JSONObject();
				sendToServer = ClientMessages.getJoinRoomRequest(comboBox.getSelectedItem().toString());
				try {
					msgSendThread.send(sendToServer);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JoinRoomFrame.this.dispose();
			}
		});
	}
	
	@SuppressWarnings("unchecked")
	private void initComboBox(){
		for (String string : ChatFrame.rooms){
			//if (string.indexOf("MainHall") < 0 ){
				comboBox.addItem(string);
			//}
		}
	}
	//|| !msgReceiveThread.getState().getRoomId().equals(string)
}
