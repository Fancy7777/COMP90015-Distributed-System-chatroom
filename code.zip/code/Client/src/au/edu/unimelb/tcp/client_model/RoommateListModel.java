package au.edu.unimelb.tcp.client_model;

import java.util.List;

import javax.swing.AbstractListModel;

import au.edu.unimelb.tcp.client.State;


public class RoommateListModel extends AbstractListModel{

	private List<State> roommates;
	
	public RoommateListModel(List<State> roommates) {
		this.roommates = roommates;
	}
	
	public void addElement(Object object) {
		if (roommates.contains(object)) {
			return;
		}
		int index = roommates.size();
		roommates.add((State)object);
		fireIntervalAdded(this, index, index);
	}
	
	public boolean removeElement(Object object) {
		int index = roommates.indexOf(object);
		if (index >= 0) {
			fireIntervalRemoved(this, index, index);
		}
		return roommates.remove(object);
	}
	
	public void clear(){
		roommates.clear();
	}
	
	public Object getElementAt(int i) {
		// TODO Auto-generated method stub
		return roommates.get(i);
	}

	public int getSize() {
		// TODO Auto-generated method stub
		return roommates.size();
	}
	
	public List<State> getRoommateList(){
		return roommates;
	}
}
