package au.edu.unimelb.tcp.client_gui;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.Socket;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import au.edu.unimelb.tcp.client.ClientMessages;
import au.edu.unimelb.tcp.client.MessageReceiveThread;
import au.edu.unimelb.tcp.client.MessageSendThread;


@SuppressWarnings("serial")
public class SetInfoFrame extends JFrame{

	private JTextField nickname;
	private JComboBox head;
	private JButton ok;
	private JButton cancel;
	private MessageSendThread msgSendThread;
	private MessageReceiveThread msgReceiveThread;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();
	
	public SetInfoFrame(MessageSendThread msgSendThread, MessageReceiveThread msgReceiveThread){
		this.init();
		setVisible(true);
		this.msgSendThread = msgSendThread;
		this.msgReceiveThread = msgReceiveThread;
		this.in = msgReceiveThread.getIn();
	}
	
	public void init(){
		this.setTitle("Set nickname");
		this.setSize(330, 180);
		//set the frame to the middle of the screen
		int x = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((x - this.getWidth()) / 2, (y-this.getHeight())/ 2);
		this.setResizable(false);
		
		getContentPane().setLayout(null);
		setResizable(false);

		Icon icon = new ImageIcon("images/logo1.png");
		JLabel labelIcon = new JLabel(icon);
		labelIcon.setBounds(0, 0, 324, 47);
		getContentPane().add(labelIcon);
		
		JLabel label = new JLabel("nickname:"); //nickname label
		label.setBounds(10, 60, 75, 20);
		getContentPane().add(label);
		
		nickname = new JTextField(); //nickname field
		nickname.setBounds(95, 60, 100, 20); // oringinal is 80
		getContentPane().add(nickname);
		
		JLabel label6 = new JLabel("image:");
		label6.setBounds(30, 90, 55, 20);
		getContentPane().add(label6);
		
		head = new JComboBox();//drop-down image list
		head.setBounds(95, 90, 65, 45); // oringinal is 80
		head.setMaximumRowCount(5);
		for (int i = 0; i < 12; i++) {
			head.addItem(new ImageIcon("images/32/" + i + ".png"));
		}
		head.setSelectedIndex(0);
		getContentPane().add(head);
		
		//sumbit button
		ok = new JButton("Sumbit");
		ok.setBounds(230, 65, 80, 25);
		getContentPane().add(ok);

		cancel = new JButton("Cancel");
		cancel.setBounds(230, 100, 80, 25);
		getContentPane().add(cancel);
		
		//listen on cancel button
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent event) {
				//send a guest quit message
				SetInfoFrame.this.dispose();
			}
		});
		//when closing window
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) {
				//send a guest quit message
				SetInfoFrame.this.dispose();
			}
		});
			
		//listen on sumbit button
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				try {
					submitInfo();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}
	
	private void submitInfo() throws IOException, ParseException{
		if(nickname.getText().length() == 0){
			JOptionPane.showMessageDialog(SetInfoFrame.this, "nickname is required", "SetInfo error", JOptionPane.ERROR_MESSAGE);
			nickname.requestFocusInWindow();
			return;
		}
		
		JSONObject sendToServer = new JSONObject();
		msgSendThread.getState().setImageIndex(head.getSelectedIndex());
		msgSendThread.getState().setIdentity(nickname.getText());
		//sendToServer = ClientMessages.getNewIdentityRequest(msgSendThread.getState().getIdentity());
		sendToServer = ClientMessages.getNewIdentityRequest(msgSendThread.getState().getIdentity(), head.getSelectedIndex()); // add imageIndex later
		msgSendThread.send(sendToServer);
		
		JSONObject message = (JSONObject) parser.parse(in.readLine());
		System.out.println(message);
		boolean newIdenytityApproved = Boolean.parseBoolean((String) message.get("approved"));
		if(newIdenytityApproved){
			SetInfoFrame.this.dispose();
			new ChatFrame(msgSendThread, msgReceiveThread);
		}else{
			JOptionPane.showMessageDialog(SetInfoFrame.this, 
						"nickname is invalid or already been used by other users",
						"Fail to create nickname: " + nickname.getText(), JOptionPane.ERROR_MESSAGE);
			SetInfoFrame.this.dispose();
		}
	}
}
