package au.edu.unimelb.tcp.client;

import javax.swing.ImageIcon;

public class Room {
	
	private String roomId;
	
	public Room(String roomId){
		this.roomId = roomId;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	
	public ImageIcon getRoomIcon() {
		ImageIcon image = new ImageIcon("images/" + "room2" + ".png");
		return image;
	}
}
