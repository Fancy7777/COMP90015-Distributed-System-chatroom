package au.edu.unimelb.tcp.client_gui;

public class TestFrame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ChatFrame a = new ChatFrame();
		//SetInfoFrame a = new SetInfoFrame();
		//LoginFrame a = new LoginFrame();
		//CreateRoomFrame a = new CreateRoomFrame();
	}

}
