package au.edu.unimelb.tcp.client_model;

import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import au.edu.unimelb.tcp.client.State;

public class MyCellRenderer4Roommate  extends JLabel implements ListCellRenderer{

	public Component getListCellRendererComponent(JList list, Object value,
			int index, boolean isSelected, boolean cellHasFocus) {
		// TODO Auto-generated method stub
		State state = (State) value;
		String name = state.getIdentity();
		setText(name);
		setIcon(state.getHeadIcon());
		if (isSelected) {
        	setBackground(list.getSelectionBackground());
        	setForeground(list.getSelectionForeground());
        } else {
	       setBackground(list.getBackground());
	       setForeground(list.getForeground());
        }
		 setEnabled(list.isEnabled());
	        setFont(list.getFont());
	        setOpaque(true);
		return this;
	}

}
