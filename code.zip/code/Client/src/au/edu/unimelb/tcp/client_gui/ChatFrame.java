package au.edu.unimelb.tcp.client_gui;

import java.awt.BorderLayout;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.omg.PortableInterceptor.USER_EXCEPTION;

import au.edu.unimelb.tcp.client.ClientMessages;
import au.edu.unimelb.tcp.client.MessageReceiveThread;
import au.edu.unimelb.tcp.client.MessageSendThread;
import au.edu.unimelb.tcp.client.Room;
import au.edu.unimelb.tcp.client.State;
import au.edu.unimelb.tcp.client_model.MyCellRenderer4Room;
import au.edu.unimelb.tcp.client_model.MyCellRenderer4Roommate;
import au.edu.unimelb.tcp.client_model.RoomListModel;
import au.edu.unimelb.tcp.client_model.RoommateListModel;

public class ChatFrame extends JFrame{
	
	public static ArrayList<String> rooms = new ArrayList<>();
	public static List<State> roommatesList = new ArrayList<State>();
	public static RoommateListModel roommatesListModel = new RoommateListModel(roommatesList);
	public static List<Room> roomsList = new ArrayList<Room>();
	public static RoomListModel roomsListModel = new RoomListModel(roomsList);
	
	public static JLabel currentRoomLbl;
	private JLabel currentUserLbl;
	public static JTextArea msgListArea;
	public static JTextArea sendArea; 
	public static JList roommateList;
	public static JLabel roommateLbl;
	public static JList roomList;
	public static JLabel  roomPaneLbl;
	public static JPanel roommateListPane;
	public static JPanel roomPane;
	
	static JButton createRoomBtn;
	static JButton joinRoomBtn;
	static JButton deleteRoomBtn;
	
	
	private MessageSendThread msgSendThread;
	private static MessageReceiveThread msgReceiveThread;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();

	
	public ChatFrame(MessageSendThread msgSendThread, MessageReceiveThread msgReceiveThread) throws ParseException, IOException{
		this.msgSendThread = msgSendThread;
		this.msgReceiveThread = msgReceiveThread;
		this.in = msgReceiveThread.getIn();
		this.init();
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
		runReceiveThread();
	}
	
	private void runReceiveThread() {
		// TODO Auto-generated method stub
		Thread receiveThread = new Thread(this.msgReceiveThread);
		receiveThread.start();
		Thread sendListThread= new Thread(this.msgSendThread);
		sendListThread.start();
	}

	public void init() throws ParseException, IOException{
		this.setTitle("Chatting-Room");
		this.setSize(585, 500);
		this.setResizable(false);
		
		int x = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((x - this.getWidth()) / 2, (y-this.getHeight())/ 2);
		
		//left main panel
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		//right main panel
		JPanel userPanel = new JPanel();
		userPanel.setLayout(new BorderLayout());
		
		//horizontal split panel
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				mainPanel, userPanel);
		splitPane.setDividerLocation(435);
		splitPane.setDividerSize(4);
		this.add(splitPane, BorderLayout.CENTER);
		
		//top-left panel
		JPanel infoPanel = new JPanel();
		infoPanel.setLayout(new BorderLayout());
		//bottom-left panel
		JPanel sendPanel = new JPanel();
		sendPanel.setLayout(new BorderLayout());
		
		//vertical split panel
		JSplitPane splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				infoPanel, sendPanel);
		splitPane2.setDividerLocation(300);
		splitPane2.setDividerSize(2);
		mainPanel.add(splitPane2, BorderLayout.CENTER);
		
		currentRoomLbl = new JLabel("Welcome to Chatting-Room!");
		infoPanel.add(currentRoomLbl, BorderLayout.NORTH);
		
		msgListArea = new JTextArea();
		msgListArea.setEditable(false);
		msgListArea.setLineWrap(true);
		infoPanel.add(new JScrollPane(msgListArea, 
						JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
						JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
		
		JPanel tempPanel = new JPanel();
		tempPanel.setLayout(new BorderLayout());
		sendPanel.add(tempPanel, BorderLayout.NORTH);
		
		// function button panel
		JPanel btnPanel = new JPanel();
		btnPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		tempPanel.add(btnPanel, BorderLayout.CENTER);
		
		//font
		JButton fontBtn = new JButton(new ImageIcon("images/font.png"));
		fontBtn.setMargin(new Insets(0,0,0,0));
		fontBtn.setToolTipText("Font");
		btnPanel.add(fontBtn);
		
		//emoji
		JButton faceBtn = new JButton(new ImageIcon("images/sendFace.png"));
		faceBtn.setMargin(new Insets(0,0,0,0));
		faceBtn.setToolTipText("Emoji");
		btnPanel.add(faceBtn);
		
		//file
		JButton shakeBtn = new JButton(new ImageIcon("images/shake.png"));
		shakeBtn.setMargin(new Insets(0,0,0,0));
		shakeBtn.setToolTipText("Shake");
		btnPanel.add(shakeBtn);
		
		//send
		JButton sendFileBtn = new JButton(new ImageIcon("images/sendPic.png"));
		sendFileBtn.setMargin(new Insets(0,0,0,0));
		sendFileBtn.setToolTipText("File");
		btnPanel.add(sendFileBtn);
		
		//send area
		sendArea = new JTextArea();
		sendArea.setLineWrap(true);
		sendPanel.add(new JScrollPane(sendArea, 
						JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
						JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
		
		// room operate button panel
		JPanel btn4Panel = new JPanel();
		btn4Panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		this.add(btn4Panel, BorderLayout.SOUTH);
		createRoomBtn = new JButton("Create Room");
		createRoomBtn.setToolTipText("Create a new room locally");
		btn4Panel.add(createRoomBtn);
		joinRoomBtn = new JButton("Join Room");
		joinRoomBtn.setToolTipText("Join to selected room");
		btn4Panel.add(joinRoomBtn);
		deleteRoomBtn = new JButton("Delete Room");
		deleteRoomBtn.setToolTipText("Delete a local room");
		btn4Panel.add(deleteRoomBtn);
		JButton submitBtn = new JButton("Send");
		submitBtn.setToolTipText("Send message with Enter key");
		btn4Panel.add(submitBtn);
		sendPanel.add(btn4Panel, BorderLayout.SOUTH);
		
		//roommate panel
		roommateListPane = new JPanel();
		roommateListPane.setLayout(new BorderLayout());
		roommateLbl = new JLabel("people in this room");
		roommateListPane.add(roommateLbl, BorderLayout.NORTH);
		
		//room panel
		roomPane = new JPanel();
		roomPane.setLayout(new BorderLayout());
		roomPaneLbl = new JLabel("room informations");
		roomPane.add(roomPaneLbl, BorderLayout.NORTH);
		
		// split user and 
		JSplitPane splitPane3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				roommateListPane, roomPane);
		splitPane3.setDividerLocation(150);
		splitPane3.setDividerSize(1);
		userPanel.add(splitPane3, BorderLayout.CENTER);
		
		//current user
		JPanel currentUserPane = new JPanel();
		currentUserPane.setLayout(new BorderLayout());
		currentUserPane.add(new JLabel("current user"), BorderLayout.NORTH);
		
		// �ұ��û��б�����һ���ָ�����
		JSplitPane splitPane4 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				splitPane3, currentUserPane);
		splitPane4.setDividerLocation(350);
		splitPane4.setDividerSize(1);
		userPanel.add(splitPane4, BorderLayout.CENTER);

		//��ǰ�û���ϢLabel
		currentUserLbl = new JLabel();
		currentUserPane.add(currentUserLbl);
		

		
		roommateList = new JList(roommatesListModel);
		roommateList.setCellRenderer(new MyCellRenderer4Roommate());
		
		roommateListPane.add(new JScrollPane(roommateList,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
		
		roomList = new JList(roomsListModel);
		roomList.setCellRenderer(new MyCellRenderer4Room());
		
		roomPane.add(new JScrollPane(roomList,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
		///////////////////////ע���¼�������/////////////////////////
		//�رմ���
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) {
				try {
					logout();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		
		//�����ı���Ϣ
		sendArea.addKeyListener(new KeyAdapter(){   
			public void keyPressed(KeyEvent e){   
				if(e.getKeyCode() == Event.ENTER){   
					try {
						sendTxtMsg();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}   
		});
		
		submitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				try {
					sendTxtMsg();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		createRoomBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				new CreateRoomFrame(msgSendThread, msgReceiveThread);
			};
		});
		
		joinRoomBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				new JoinRoomFrame(msgSendThread, msgReceiveThread);
			}
		});
		
		deleteRoomBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				int select = JOptionPane.showConfirmDialog(ChatFrame.this,
						"Do you really want to delete the room "+ msgReceiveThread.getState().getRoomId() + 
						"? After that, you will go back to MainHall.", "Delete Current Room",
						JOptionPane.YES_NO_OPTION);
				if (select == JOptionPane.YES_OPTION) {
					JSONObject sendToServer = new JSONObject();
					sendToServer = ClientMessages.getDeleteRoomRequest(msgReceiveThread.getState().getRoomId());
					try {
						msgSendThread.send(sendToServer);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else{
					
				}
			}
		});
		
		this.loadData();  //���س�ʼ����
	}
	
	/**  load data
	 * @throws IOException 
	 * @throws ParseException */
	public void loadData() throws ParseException, IOException{
		//load current user's data
		currentUserLbl.setIcon(
				new ImageIcon("images/64/" + msgSendThread.getState().getImageIndex() + ".png"));
		currentUserLbl.setText(msgSendThread.getState().getIdentity());
	}
	
	public static void sendListMsg(MessageSendThread msgSendThread) throws IOException{
		JSONObject sendToServer = new JSONObject();
		sendToServer = ClientMessages.getListRequest();
		msgSendThread.send(sendToServer);
	}
	
	public static void sendWhoMsg(MessageSendThread msgSendThread) throws IOException{
		JSONObject sendToServer = new JSONObject();
		sendToServer = ClientMessages.getWhoRequest();
		msgSendThread.send(sendToServer);
	}
	
	public static void updateCurrentRoomInfo(){
		currentRoomLbl.setText("current room: " + msgReceiveThread.getState().getRoomId());
	}
	
	public void sendTxtMsg() throws IOException{
		String content = sendArea.getText();
		if ("".equals(content)) { //������
			JOptionPane.showMessageDialog(ChatFrame.this, "Cannot send empty message!",
					"Send error", JOptionPane.ERROR_MESSAGE);
		} else {
			//appendTxt2MsgListArea("You: " + content);
			JSONObject sendToServer = new JSONObject();
			sendToServer = ClientMessages.getMessage(content);
			msgSendThread.send(sendToServer);
			
			//JTextArea�а���Enter��ʱ��������ݲ��ص�����
			InputMap inputMap = sendArea.getInputMap();
			ActionMap actionMap = sendArea.getActionMap();
			Object transferTextActionKey = "TRANSFER_TEXT";
			inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,0),transferTextActionKey);
			actionMap.put(transferTextActionKey,new AbstractAction() {
				public void actionPerformed(ActionEvent e) {
					sendArea.setText("");
					sendArea.requestFocus();
				}
			});
			sendArea.setText("");
		}
	}

	/** �رտͻ��� 
	 * @throws IOException */
	private void logout() throws IOException {
		int select = JOptionPane.showConfirmDialog(ChatFrame.this,
				"Sure to quit? \n\n Will be disconnect with server!", "Quit Chatting-Room",
				JOptionPane.YES_NO_OPTION);
		if (select == JOptionPane.YES_OPTION) {
			JSONObject sendToServer = new JSONObject();
			sendToServer = ClientMessages.getQuitRequest();
			msgSendThread.send(sendToServer);
			System.exit(0);
		}else{
			this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		}
	}
	
	public static void appendTxt2MsgListArea(String txt) {
		ChatFrame.msgListArea.append(txt);
		ChatFrame.msgListArea.append("\n");
		//�ѹ�궨λ���ı�������һ��
		//ChatFrame.msgListArea.setCaretPosition(ChatFrame.msgListArea.getDocument().getLength());
	}
	
	public static void setButtonIsOwner(){
		createRoomBtn.setEnabled(false);
		joinRoomBtn.setEnabled(false);
		deleteRoomBtn.setEnabled(true);
	}
	
	public static void setButtonNotOwner(){
		createRoomBtn.setEnabled(true);
		joinRoomBtn.setEnabled(true);
		deleteRoomBtn.setEnabled(false);		
	}
}
