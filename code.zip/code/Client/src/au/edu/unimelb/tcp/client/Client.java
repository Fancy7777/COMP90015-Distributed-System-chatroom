package au.edu.unimelb.tcp.client;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import org.json.simple.parser.ParseException;
import org.jvnet.substance.skin.SubstanceBusinessLookAndFeel;
import org.jvnet.substance.skin.SubstanceOfficeSilver2007LookAndFeel;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import java.security.KeyStore;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;
import au.edu.unimelb.tcp.client_gui.LoginFrame;

public class Client {
	private static final String CLIENT_KEY_STORE_PASSWORD       = "123456";
    private static final String CLIENT_TRUST_KEY_STORE_PASSWORD = "123456";
    
	public static void main(String[] args) throws IOException, ParseException {
		Socket socket = null;
		String identity = "";
		SSLSocket  sslSocket = null;
		boolean debug = false;
		try {
			//load command line args
			ComLineValues values = new ComLineValues();
			CmdLineParser parser = new CmdLineParser(values);
			try {
				parser.parseArgument(args);
				String hostname = values.getHost();
				//identity = values.getIdeneity();
				int port = values.getPort();
				debug = values.isDebug();
				SSLContext ctx = SSLContext.getInstance("SSL");

	            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
	            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");

	            KeyStore ks = KeyStore.getInstance("JKS");
	            KeyStore tks = KeyStore.getInstance("JKS");

	            ks.load(new FileInputStream("data/kclient.keystore"), CLIENT_KEY_STORE_PASSWORD.toCharArray());
	            tks.load(new FileInputStream("data/tclient.keystore"), CLIENT_TRUST_KEY_STORE_PASSWORD.toCharArray());

	            kmf.init(ks, CLIENT_KEY_STORE_PASSWORD.toCharArray());
	            tmf.init(tks);

	            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

	            sslSocket = (SSLSocket) ctx.getSocketFactory().createSocket(hostname, port);
				System.out.println(sslSocket);
			} catch (CmdLineException e) {
				e.printStackTrace();
			} catch(Exception e){
				e.printStackTrace();
			}
			
			State state = new State(identity, "", 0);
			
			JFrame.setDefaultLookAndFeelDecorated(true);
			JDialog.setDefaultLookAndFeelDecorated(true);
			try {
				UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
				//UIManager.setLookAndFeel(new SubstanceOfficeSilver2007LookAndFeel());
				//UIManager.setLookAndFeel(new SubstanceBusinessLookAndFeel());
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			MessageSendThread msgSendThread = new MessageSendThread(sslSocket, state, debug);
			MessageReceiveThread msgReceiveThread = new MessageReceiveThread(sslSocket, state, msgSendThread, debug);
			
			LoginFrame loginFrame = new LoginFrame(msgSendThread, msgReceiveThread);
			
			/*// start sending thread
			MessageSendThread messageSendThread = new MessageSendThread(socket, state, debug);
			Thread sendThread = new Thread(messageSendThread);
			sendThread.start();
			
			// start receiving thread
			Thread receiveThread = new Thread(new MessageReceiveThread(socket, state, messageSendThread, debug));
			receiveThread.start();*/
			
		} catch (UnknownHostException e) {
			System.out.println("Unknown host");
		} catch (IOException e) {
			System.out.println("Communication Error: " + e.getMessage());
			JOptionPane.showMessageDialog(new JFrame(), 
					"fail to connect to the server","unconnected", JOptionPane.ERROR_MESSAGE);//fail to connect to server
		}
	}
}
