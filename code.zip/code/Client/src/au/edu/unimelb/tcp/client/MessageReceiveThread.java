package au.edu.unimelb.tcp.client;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;
import javax.swing.JList;
import javax.swing.JScrollPane;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import au.edu.unimelb.tcp.client_gui.ChatFrame;
import au.edu.unimelb.tcp.client_model.MyCellRenderer4Room;
import au.edu.unimelb.tcp.client_model.RoomListModel;

public class MessageReceiveThread implements Runnable {

	private Socket socket;
	private State state;
	private boolean debug;
	private String owner;

	private BufferedReader in;
	private DataOutputStream out;

	private JSONParser parser = new JSONParser();

	private boolean run = true;
	
	private MessageSendThread messageSendThread;
	
	private static final String CLIENT_KEY_STORE_PASSWORD       = "123456";
    private static final String CLIENT_TRUST_KEY_STORE_PASSWORD = "123456";

	public MessageReceiveThread(Socket socket, State state, MessageSendThread messageSendThread, boolean debug) throws IOException {
		
		this.socket = socket;
		this.state = state;
		this.messageSendThread = messageSendThread;
		this.debug = debug;
		this.in = new BufferedReader(new InputStreamReader(
				socket.getInputStream(), "UTF-8"));
		this.out = new DataOutputStream(socket.getOutputStream());
	}

	public void run() {

		try {
			JSONObject message;
			while (run) {
				message = (JSONObject) parser.parse(in.readLine());
				//System.out.println(message.toJSONString());
				if (debug) {
					System.out.println("Receiving: " + message.toJSONString());
					System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				}
				MessageReceive(socket, message);
			}
			System.exit(0);
			in.close();
			socket.close();
		} catch (ParseException e) {
			System.out.println("Message Error: " + e.getMessage());
			System.exit(1);
		} catch (IOException e) {
			System.out.println("Communication Error: " + e.getMessage());
			System.exit(1);
		}

	}

	public void MessageReceive(Socket socket, JSONObject message)
			throws IOException, ParseException {
		String type = (String) message.get("type");
		
		// server reply of #newidentity
		if (type.equals("newidentity")) {
			boolean approved = Boolean.parseBoolean((String) message.get("approved"));
			
			// terminate program if failed
			if (!approved) {
				System.out.println(state.getIdentity() + " already in use.");
				socket.close();
				System.exit(1);
			}
			return;
		}
		
		// server reply of #list
		if (type.equals("roomlist")) {
			JSONArray array = (JSONArray) message.get("rooms");
			// print all the rooms
			System.out.print("List of chat rooms:");
			for (int i = 0; i < array.size(); i++) {
				System.out.print(" " + array.get(i));
			}
			System.out.println();
			System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			
			updateRooms(array);
			
			return;
		}

		// server sends roomchange
		if (type.equals("roomchange")) {

			// identify whether the user has quit!
			if (message.get("roomid").equals("")) {
				// quit initiated by the current client
				if (message.get("identity").equals(state.getIdentity())) {
					System.out.println(message.get("identity") + " has quit!");
					in.close();
					System.exit(1);
				} else {
					System.out.println(message.get("identity") + " has quit!");
					ChatFrame.appendTxt2MsgListArea(message.get("identity") + " has quit!");
					System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
					ChatFrame.sendWhoMsg(messageSendThread);
				}
			// identify whether the client is new or not
			} else if (message.get("former").equals("")) {
				// change state if it's the current client
				if (message.get("identity").equals(state.getIdentity())) {
					state.setRoomId((String) message.get("roomid"));
				}
				System.out.println(message.get("identity") + " moves to "
						+ (String) message.get("roomid"));
				ChatFrame.appendTxt2MsgListArea(message.get("identity") + " moves to "
						+ (String) message.get("roomid"));
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				ChatFrame.currentRoomLbl.setText("You are now in: " + state.getRoomId()); 
				ChatFrame.sendWhoMsg(messageSendThread);
			// identify whether roomchange actually happens
			} else if (message.get("former").equals(message.get("roomid"))) {
				System.out.println("room unchanged");
				ChatFrame.appendTxt2MsgListArea("room unchanged");
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				ChatFrame.sendWhoMsg(messageSendThread);
			}
			// print the normal roomchange message
			else {
				// change state if it's the current client
				if (message.get("identity").equals(state.getIdentity())) {
					state.setRoomId((String) message.get("roomid"));
					ChatFrame.currentRoomLbl.setText("You are now in: " + state.getRoomId()); 
				}
				
				System.out.println(message.get("identity") + " moves from " + message.get("former") + " to "
						+ message.get("roomid"));
				ChatFrame.appendTxt2MsgListArea(message.get("identity") + " moves from " + message.get("former") + " to "
						+ message.get("roomid"));
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				ChatFrame.sendWhoMsg(messageSendThread);
			}
			return;
		}
		
		// server reply of #who
		if (type.equals("roomcontents")) {
			JSONArray array = (JSONArray) message.get("identities");
			owner = message.get("owner").toString();
			if(owner.equals(state.getIdentity())){
				ChatFrame.setButtonIsOwner();
			}else{
				ChatFrame.setButtonNotOwner();
			}
			System.out.print(message.get("roomid") + " contains");
			for (int i = 0; i < array.size(); i++) {
				System.out.print(" " + array.get(i));
				if (message.get("owner").equals(array.get(i))) {
					System.out.print("*");
				}
			}
			System.out.println();
			JSONArray array1 = (JSONArray) message.get("indexs");
			System.out.print("index" + " contains");
			for (int i = 0; i < array1.size(); i++) {
				System.out.print(" " + array1.get(i));
			}
			
			System.out.println();
			System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			
			updateUsers(array, array1);
			
			return;
		}
		
		// server forwards message
		if (type.equals("message")) {
			System.out.println(message.get("identity") + ": "
					+ message.get("content"));
			ChatFrame.appendTxt2MsgListArea(message.get("identity") + ": " + message.get("content"));
			System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			return;
		}
		
		
		// server reply of #createroom
		if (type.equals("createroom")) {
			boolean approved = Boolean.parseBoolean((String)message.get("approved"));
			String temp_room = (String)message.get("roomid");
			if (!approved) {
				System.out.println("Create room " + temp_room + " failed."); //msgbox
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			else {
				System.out.println("Room " + temp_room + " is created."); //msgbox
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			return;
		}
		
		// server reply of # deleteroom
		if (type.equals("deleteroom")) {
			boolean approved = Boolean.parseBoolean((String)message.get("approved"));
			String temp_room = (String)message.get("roomid");
			if (!approved) {
				System.out.println("Delete room " + temp_room + " failed."); //msgbox
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			else {
				System.out.println("Room " + temp_room + " is deleted."); // msgbox
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			return;
		}
		
		// server directs the client to another server
		if (type.equals("route")) {
			SSLSocket  sslSocket = null;
			String temp_room = (String)message.get("roomid");
			String host = (String)message.get("host");
			int port = Integer.parseInt((String)message.get("port"));
			
			// connect to the new server
			if (debug) {
				System.out.println("Connecting to server " + host + ":" + port);
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			
			try{
				SSLContext ctx = SSLContext.getInstance("SSL");

	            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
	            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");

	            KeyStore ks = KeyStore.getInstance("JKS");
	            KeyStore tks = KeyStore.getInstance("JKS");

	            ks.load(new FileInputStream("data/kclient.keystore"), CLIENT_KEY_STORE_PASSWORD.toCharArray());
	            tks.load(new FileInputStream("data/tclient.keystore"), CLIENT_TRUST_KEY_STORE_PASSWORD.toCharArray());

	            kmf.init(ks, CLIENT_KEY_STORE_PASSWORD.toCharArray());
	            tmf.init(tks);

	            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

	            sslSocket = (SSLSocket) ctx.getSocketFactory().createSocket(host, port);
				System.out.println(sslSocket);
				
			}catch(Exception e){
				
			}
			
			// send #movejoin
			DataOutputStream out = new DataOutputStream(sslSocket.getOutputStream());
			JSONObject request = ClientMessages.getMoveJoinRequest(state.getIdentity(), state.getRoomId(), temp_room);
			if (debug) {
				System.out.println("Sending: " + request.toJSONString());
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			send(out, request);
			
			// wait to receive serverchange
			BufferedReader temp_in = new BufferedReader(new InputStreamReader(sslSocket.getInputStream()));
			JSONObject obj = (JSONObject) parser.parse(temp_in.readLine());
			
			if (debug) {
				System.out.println("Receiving: " + obj.toJSONString());
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			
			// serverchange received and switch server
			if (obj.get("type").equals("serverchange") && obj.get("approved").equals("true")) {
				messageSendThread.switchServer(sslSocket, out);
				switchServer(sslSocket, temp_in);
				String serverid = (String)obj.get("serverid");
				ChatFrame.appendTxt2MsgListArea(state.getIdentity() + " switches to server " + serverid);
				System.out.println(state.getIdentity() + " switches to server " + serverid);
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			// receive invalid message
			else {
				temp_in.close();
				out.close();
				sslSocket.close();
				System.out.println("Server change failed"); //msgbox
				ChatFrame.appendTxt2MsgListArea("Server change failed");
				System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			}
			return;
		}
		
		if (debug) {
			System.out.println("Unknown Message: " + message);
			System.out.print("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
		}
	}
	
	private void updateUsers(JSONArray array, JSONArray array1) {
		ChatFrame.roommatesListModel.clear();
		for(int i = 0; i < array.size(); i++){
			ChatFrame.roommatesListModel.addElement(new State(array.get(i).toString(), "", ((Long) array1.get(i)).intValue()));
		}
	}

	public void switchServer(Socket temp_socket, BufferedReader temp_in) throws IOException {
		in.close();
		in = temp_in;
		socket.close();
		socket = temp_socket;
	}

	private void send(DataOutputStream out, JSONObject obj) throws IOException {
		out.write((obj.toJSONString() + "\n").getBytes("UTF-8"));
		out.flush();
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public BufferedReader getIn() {
		return in;
	}

	public void setIn(BufferedReader in) {
		this.in = in;
	}
	
	private void updateRooms(JSONArray array){
		ChatFrame.rooms.clear();
		ChatFrame.roomsListModel.clear();
		for(int i = 0; i < array.size(); i++){
			ChatFrame.rooms.add(array.get(i).toString());
			ChatFrame.roomsListModel.addElement(new Room(array.get(i).toString()));
		}
	}
}
