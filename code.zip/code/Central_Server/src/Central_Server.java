import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyStore;
import java.util.ArrayList;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.TrustManagerFactory;

public class Central_Server {
	private static final String SERVER_KEY_STORE_PASSWORD       = "123456";
	private static final String SERVER_TRUST_KEY_STORE_PASSWORD = "123456";

	private static SSLServerSocket     serverSocket;
	public static ArrayList<User_info> user_infos = new ArrayList<>();
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int port = 80;
		try{
			SSLContext ctx = SSLContext.getInstance("SSL");

			//Using SunX509 for encription
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");

            KeyStore ks = KeyStore.getInstance("JKS");
            KeyStore tks = KeyStore.getInstance("JKS");

            //load certificates
            ks.load(new FileInputStream("data/kserver.keystore"), SERVER_KEY_STORE_PASSWORD.toCharArray());
            tks.load(new FileInputStream("data/tserver.keystore"), SERVER_TRUST_KEY_STORE_PASSWORD.toCharArray());

            //inintial encryption
            kmf.init(ks, SERVER_KEY_STORE_PASSWORD.toCharArray());
            tmf.init(tks);

            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            serverSocket = (SSLServerSocket) ctx.getServerSocketFactory().createServerSocket(port);
			
		}catch(Exception e){
			
		}
		
		File filename = new File("Userinfo.txt");
		InputStreamReader reader = new InputStreamReader(
				new FileInputStream(filename));
		@SuppressWarnings("resource")
		BufferedReader br = new BufferedReader(reader);
		String line = null;
		line = br.readLine();
		while (line != null) {
			UserFileReadLine userFileReadLine = new UserFileReadLine(
					line);
			user_infos.add(new User_info(userFileReadLine
						.getUsername(), userFileReadLine
						.getPassword()));
			line = br.readLine();
		}
		
		/*for(User_info user_info : user_infos){
			System.out.println(user_info.getUsername()+"\t"+user_info.getPassword());
		}*/
		
		while(true){
			Socket socket = serverSocket.accept();
			CentralThread centralThread = new CentralThread(socket);
			centralThread.start();
		}
		
	}

}
