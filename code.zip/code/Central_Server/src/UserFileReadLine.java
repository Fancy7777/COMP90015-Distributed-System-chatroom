public class UserFileReadLine {
	String username;
	String password;

	public UserFileReadLine(String line) {
		String[] portion = line.split("\t");
		setUsername(portion[0]);
		setPassword(portion[1]);
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
