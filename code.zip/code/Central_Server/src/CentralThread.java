import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class CentralThread extends Thread{

	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;
	private JSONParser parser = new JSONParser();
	
	
	public CentralThread(Socket socket) throws IOException{
		
		this.socket = socket;
		//this.out = new PrintWriter(socket.getOutputStream());
		this.out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
		this.in = new BufferedReader(new InputStreamReader(
				socket.getInputStream(), "UTF-8"));
		System.out.println(socket);
	}
	
	public void run() {

		try {
			while(true){
				JSONObject message = (JSONObject) parser.parse(in.readLine());
				System.out.println(message);
				String username = message.get("username").toString();
				String password = message.get("password").toString();
				JSONObject reply2server = new JSONObject();
				reply2server = CentralMessages.getVarify(CheckValid(username, password));
				out.println(reply2server);
				out.flush();
			}
		} catch (ParseException e) {
			System.out.println("Message Error: " + e.getMessage());
			System.exit(1);
		} catch (IOException e) {
			System.out.println("Communication Error: " + e.getMessage());
			System.exit(1);
		} finally{
			out.close();
			try {
				in.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private Boolean CheckValid(String username, String password) {
		for(User_info user_infos : Central_Server.user_infos){
			if(user_infos.getUsername().equals(username) && user_infos.getPassword().equals(password))
				return true;
		}
		return false;
	}
}
