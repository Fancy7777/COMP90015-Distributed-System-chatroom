import org.json.simple.JSONObject;

public class CentralMessages {
	
	@SuppressWarnings("unchecked")
	public static JSONObject getVarify(Boolean boolean1) {
		JSONObject reply = new JSONObject();
		String booleanString = boolean1.toString();
		reply.put("type", "loginReply");
		reply.put("approved", booleanString);
		return reply;		
	}
	
}
